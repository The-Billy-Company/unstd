"""Build both isolated JSON kernels with the project's normal native hook."""
from pathlib import Path
from tempfile import TemporaryDirectory
import hatch_build

root = Path(__file__).resolve().parent
for variant in ("before", "after"):
    with TemporaryDirectory(prefix="unstd-array-proof-") as temporary:
        hook = hatch_build.CustomBuildHook(
            str(root / variant), {}, None, None, temporary, "wheel"
        )
        hook._compiler_commands = hatch_build._compiler_commands()
        data = {"force_include": {}}
        hook._build_module(
            "unstd.serde._json_native", Path(temporary), "editable", data
        )
        binaries = list((root / variant / "src/unstd/serde").glob("_json_native*.so"))
        binaries += list((root / variant / "src/unstd/serde").glob("_json_native*.pyd"))
        if not binaries:
            raise RuntimeError(f"Native JSON build failed for {variant}")
        print(variant, binaries)
