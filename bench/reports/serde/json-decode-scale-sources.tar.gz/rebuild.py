"""Rebuild both retained native codecs with identical local compiler flags."""
from pathlib import Path
import shlex
import subprocess
import sysconfig
root = Path(__file__).resolve().parent
for label in ("before", "after"):
    source = root / label
    output = source / "src/unstd/serde" / ("_json_native" + sysconfig.get_config_var("EXT_SUFFIX"))
    command = [*shlex.split(sysconfig.get_config_var("LDSHARED")), "-O3", "-fPIC",
               "-I" + sysconfig.get_path("include"), str(source / "native/serde/src/adapter.c"),
               "-o", str(output)]
    print(shlex.join(command))
    subprocess.run(command, check=True)
