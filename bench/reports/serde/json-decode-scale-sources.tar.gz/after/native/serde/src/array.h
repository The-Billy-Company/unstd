/* Delimiter framing for one bounded JSON-array window.
 *
 * The caller starts at a top-level item boundary. This helper only identifies
 * complete item spans; the existing JSON decoder remains authoritative for
 * values, syntax, depth and diagnostics. Incomplete suffixes stay on the Python
 * stream walker's incremental path, so no accumulated item is rescanned here.
 * Exact Unicode is immutable and held by the call. The scan neither allocates,
 * invokes Python nor releases the GIL; only the final result tuple allocates.
 */

static PyObject *
array_boundary(PyObject *module, PyObject *const *args, Py_ssize_t count)
{
    (void)module;
    if (count != 2) {
        PyErr_SetString(PyExc_TypeError,
                        "array_boundary() requires text and start");
        return NULL;
    }
    PyObject *text = args[0];
    if (!PyUnicode_CheckExact(text)) {
        Py_RETURN_NOTIMPLEMENTED;
    }
    if (!PyLong_CheckExact(args[1])) {
        PyErr_SetString(PyExc_TypeError,
                        "array_boundary() start must be an exact integer");
        return NULL;
    }
    Py_ssize_t start = PyLong_AsSsize_t(args[1]);
    if (start == -1 && PyErr_Occurred()) {
        return NULL;
    }
    Py_ssize_t length = PyUnicode_GET_LENGTH(text);
    if (start < 0 || start > length) {
        PyErr_SetString(PyExc_ValueError,
                        "array_boundary() start is outside text");
        return NULL;
    }
    int kind = PyUnicode_KIND(text);
    const void *data = PyUnicode_DATA(text);
    Py_ssize_t depth = 0;
    Py_ssize_t boundary = -1;
    int quoted = 0;
    int escaped = 0;
    int closed = 0;
    for (Py_ssize_t position = start; position < length; position++) {
        Py_UCS4 symbol = PyUnicode_READ(kind, data, position);
        if (quoted) {
            if (escaped) {
                escaped = 0;
            } else if (symbol == '\\') {
                escaped = 1;
            } else if (symbol == '"') {
                quoted = 0;
            }
        } else if (symbol == '"') {
            if (kind == PyUnicode_1BYTE_KIND) {
                /* The shared quote finder uses memchr and backslash parity,
                 * skipping string payload in bulk. It is a framing operation:
                 * malformed escapes still go to the authoritative decoder. */
                const char *bytes = data;
                const char *after = skip_json_string(bytes + position + 1,
                                                     bytes + length);
                if (after == NULL) {
                    break;
                }
                position = after - bytes - 1;
            } else {
                quoted = 1;
            }
        } else if (symbol == '[' || symbol == '{') {
            depth++;
        } else if (symbol == ']' && depth == 0) {
            boundary = position;
            closed = 1;
            break;
        } else if (symbol == ']' || symbol == '}') {
            /* An unmatched object closer is malformed. Keep any earlier
             * complete prefix and let the decoder/walker reject the suffix. */
            if (depth == 0) {
                break;
            }
            depth--;
        } else if (symbol == ',' && depth == 0) {
            boundary = position;
        }
    }
    return Py_BuildValue("(nO)", boundary, closed ? Py_True : Py_False);
}
