"""Private checked dataset offset-copy kernel."""

from collections.abc import Buffer

KERNEL_VERSION: int

def row(data: Buffer, index_offset: int, count: int, position: int, /) -> bytes: ...
def take(
    data: Buffer,
    index_offset: int,
    count: int,
    positions: tuple[int, ...],
    /,
) -> list[bytes]: ...
def span(
    data: Buffer, index_offset: int, count: int, start: int, stop: int, /
) -> bytes: ...
def validate(data: Buffer, index_offset: int, count: int, /) -> None: ...
