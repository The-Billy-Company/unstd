"""Transport policy — one verifying TLS client context, with no way to opt out.

A TLS context assembled at its call site looks reasonable in review and is the
usual home of ``verify=False``: the flag gets added for one local sidecar, and
nothing keeps the next caller from copying the line. Naming the policy once, in
a function that has no parameter for skipping verification, is the whole point.

This module is pure stdlib and imports on a base install. It lives under
:mod:`unstd.crypto` because transport security is the same subject as the rest
of the seam.
"""

from __future__ import annotations

import ssl


type TlsContext = ssl.SSLContext
"""The context type, re-exported so a caller can annotate without importing ``ssl``."""


MINIMUM_VERSION = ssl.TLSVersion.TLSv1_3
"""The floor this policy asserts by default.

TLS 1.3 is required for OpenSSL's hybrid post-quantum key exchange, including
X25519MLKEM768 in OpenSSL >= 3.5. The protocol floor alone does not guarantee
that group: negotiation also depends on the runtime, configuration and peer.
Hybrid key shares increase wire size; this policy does not force a group or
claim unchanged handshake overhead. TLS 1.2 remains an explicit legacy choice.
"""

LEGACY_MINIMUM_VERSION = ssl.TLSVersion.TLSv1_2
"""The floor for a peer that has *not* been shown to negotiate 1.3.

Naming it is the point. A service dials both kinds of peer, and the honest
difference between them is one argument at one call site — not a second
hand-rolled context, which is where the flag that turns verification off
eventually gets added.
"""

_FLOOR = ssl.TLSVersion.TLSv1_2
"""Below this there is nothing left to negotiate down to, so it is refused."""


def client_context(
    *,
    cafile: str | None = None,
    certfile: str | None = None,
    keyfile: str | None = None,
    minimum_version: ssl.TLSVersion = MINIMUM_VERSION,
) -> ssl.SSLContext:
    """A verifying TLS client context — one policy, not one per transport.

    Hostname checking and certificate verification are on (stdlib's
    ``create_default_context`` defaults, restated here so a future edit has to
    argue with them). *cafile* pins a private root, which is how a self-signed
    sidecar certificate is trusted without weakening the public path. Passing
    *certfile* turns it into mTLS — with *keyfile* beside it, or alone when the
    PEM carries its own key, the usual bundle shape. A *keyfile* with no
    certificate raises: a client that asked for mTLS must never quietly dial
    without it and fail at the peer's handshake instead.

    Explicitly empty certificate paths raise: use ``None`` to omit one. An empty
    *cafile* must never silently revert to default public trust, and empty client
    identity paths must never silently drop mTLS.

    *minimum_version* is the one dial, and it stops at
    :data:`LEGACY_MINIMUM_VERSION` — TLS 1.0 and 1.1 raise rather than quietly
    widening what the process will speak. There is deliberately no
    ``verify=False`` / ``insecure=True`` parameter: a seam that can be asked to
    skip verification is a seam that eventually is.

    Construct once per trust/client-identity policy and reuse the returned
    context for connections. Finish configuration before its first use and do
    not mutate it while connections use it. Rebuild it when certificates or
    trust policy rotate. Each call returns a fresh context owned by its caller;
    there is no global cache sharing mutable security policy.
    """
    if minimum_version < _FLOOR:
        msg = f"TLS floor {minimum_version.name} is below {_FLOOR.name}; it will not be honored here"
        raise ValueError(msg)
    for name, path in (
        ("cafile", cafile),
        ("certfile", certfile),
        ("keyfile", keyfile),
    ):
        if path == "":
            msg = f"{name} must not be empty; use None to omit a certificate path"
            raise ValueError(msg)
    if keyfile and not certfile:
        msg = "keyfile without certfile is not mTLS; pass the certificate it belongs to"
        raise ValueError(msg)
    ctx = ssl.create_default_context(cafile=cafile)
    ctx.minimum_version = minimum_version
    if certfile:
        ctx.load_cert_chain(certfile=certfile, keyfile=keyfile)
    return ctx


__all__ = ["LEGACY_MINIMUM_VERSION", "MINIMUM_VERSION", "TlsContext", "client_context"]
