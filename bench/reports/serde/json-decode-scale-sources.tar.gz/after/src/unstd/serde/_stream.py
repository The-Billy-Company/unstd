"""Incremental framing for a top-level JSON array, with one decode per item."""

from __future__ import annotations

import codecs
import json
import re
from typing import TYPE_CHECKING, Any, NoReturn

from unstd.serde import jsonx


if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

    from unstd.serde.jsonx import _StreamReader


_TOKENS = re.compile(r'["\\\[\]{},]')
_NONSPACE = re.compile(r"[^ \t\r\n]")
_WHITESPACE = " \t\r\n"


def _invalid(message: str, document: str, position: int = 0) -> NoReturn:
    """Report the current framing window without retaining the whole source."""
    raise json.JSONDecodeError(message, document, position)


def _read_binary(fp: _StreamReader, size: int) -> bytes | bytearray:
    """Read a bounded binary chunk and reject a stream that changes type."""
    chunk = fp.read(size)
    if not isinstance(chunk, bytes | bytearray):
        message = "JSON binary stream read() must return bytes or bytearray"
        raise TypeError(message)
    return chunk


def _text_chunks(fp: _StreamReader, size: int) -> Iterator[str]:
    """Decode short binary reads incrementally using stdlib's encoding rules."""
    chunk = fp.read(size)
    if isinstance(chunk, str):
        while chunk:
            yield chunk
            chunk = fp.read(size)
            if not isinstance(chunk, str):
                message = "JSON text stream read() must return str"
                raise TypeError(message)
        return
    if not isinstance(chunk, bytes | bytearray):
        message = "JSON stream read() must return str, bytes or bytearray"
        raise TypeError(message)

    # Four initial bytes distinguish BOMs and unmarked UTF-8/16/32. Even a
    # one-byte/short-read source must be sniffed before decoding its first byte.
    prefix = bytes(chunk)
    eof = not chunk
    while len(prefix) < 4 and not eof:
        part = _read_binary(fp, min(size, 4 - len(prefix)))
        prefix += part
        eof = not part
    decoder = codecs.getincrementaldecoder(json.detect_encoding(prefix))(
        "surrogatepass"
    )
    if text := decoder.decode(prefix, final=eof):
        yield text
    while not eof:
        chunk = _read_binary(fp, size)
        eof = not chunk
        if text := decoder.decode(chunk, final=eof):
            yield text


def items(
    fp: _StreamReader,
    size: int,
    decode: Callable[[str], Any],
    *,
    batch: bool = False,
) -> Iterator[Any]:
    """Frame each item in one pass, retaining only its fragments and one chunk."""
    state = "root"
    fragments: list[str] = []
    depth = 0
    quoted = False
    escaped = False
    padding = False
    carry_used = False
    native = getattr(jsonx, "_native", None)
    boundary_scan = getattr(native, "array_boundary", None) if batch else None
    for text in _text_chunks(fp, size):
        if (
            boundary_scan is not None
            and not carry_used
            and len(fragments) == 1
            and len(fragments[0]) < size
            and native is not None
            and native.dispatch_ready(decode)
        ):
            # Carry a short suffix into one bounded next window, so ordinary
            # records split by a read can still share its bulk decode. Once an
            # item reaches a window in length it stays on the incremental path;
            # never concatenate and rescan a growing large record repeatedly.
            text = fragments[0] + (" " if padding else "") + text
            fragments.clear()
            depth = 0
            quoted = escaped = padding = False
            carry_used = True
        offset = 0
        batch_allowed = True
        while offset < len(text):
            if state != "item":
                found = _NONSPACE.search(text, offset)
                if found is None:
                    break
                offset = found.start()
                if state == "tail":
                    _invalid("Extra data", text, offset)
                if state == "root":
                    if text[offset] != "[":
                        _invalid("Expecting a top-level JSON array", text, offset)
                    state = "first"
                    offset += 1
                    continue
                if text[offset] == "]":
                    if state != "first":
                        _invalid("Expecting value", text, offset)
                    state = "tail"
                    offset += 1
                    continue
                state = "item"

            if (
                boundary_scan is not None
                and batch_allowed
                and not fragments
                and native is not None
                and native.dispatch_ready(decode)
            ):
                span = boundary_scan(text, offset)
                if span is not NotImplemented:
                    end, closed = span
                    if end > offset:
                        # This bounded batch has no custom callbacks. A failed
                        # speculative parse can therefore use the original item
                        # walker without replaying user code or hiding a valid
                        # prefix before a malformed later record.
                        try:
                            values = decode("[" + text[offset:end] + "]")
                        except (ValueError, RecursionError):
                            # Retry this window only once. Repeating the failed
                            # suffix batch before every valid prefix item would
                            # make a late syntax error quadratic in chunk size.
                            batch_allowed = False
                        else:
                            state = "tail" if closed else "value"
                            offset = end + 1
                            carry_used = False
                            yield from values
                            del values
                            continue

            start = offset
            # An escape at the previous chunk's end consumes exactly one actual
            # character, including letters that the structural regex skips.
            if escaped:
                offset += 1
                escaped = False
            boundary = None
            for found in _TOKENS.finditer(text, offset):
                position = found.start()
                symbol = found[0]
                if quoted:
                    if escaped:
                        if position == offset:
                            escaped = False
                            offset = position + 1
                            continue
                        escaped = False
                    if symbol == "\\":
                        escaped = True
                    elif symbol == '"':
                        quoted = False
                    offset = position + 1
                    continue
                if symbol == '"':
                    quoted = True
                elif symbol == "[" or symbol == "{":
                    depth += 1
                elif depth == 0 and (symbol == "," or symbol == "]"):
                    boundary = position
                    break
                elif symbol == "]" or symbol == "}":
                    depth -= 1
                offset = position + 1

            stop = len(text) if boundary is None else boundary
            fragment = text[start:stop]
            trailing = False
            if not quoted and depth == 0:
                stripped = fragment.rstrip(_WHITESPACE)
                trailing = len(stripped) != len(fragment)
                fragment = stripped
            if fragment:
                if padding:
                    # Preserve a separator: dropping it would turn invalid `1 2`
                    # into valid `12` when a whitespace run crosses chunks.
                    fragments.append(" ")
                fragments.append(fragment)
                padding = trailing
            else:
                padding = padding or trailing
            if boundary is None:
                # A non-token after the last backslash also consumes its escape.
                escaped = escaped and offset == len(text)
                break

            encoded = "".join(fragments)
            fragments.clear()
            value = decode(encoded)
            encoded = ""
            padding = False
            carry_used = False
            state = "tail" if text[boundary] == "]" else "value"
            offset = boundary + 1
            yield value
            del value
    if state != "tail":
        # An unfinished item has no array delimiter. Do not invoke user hooks
        # for it while constructing the framing error.
        encoded = "".join(fragments)
        _invalid("Unterminated JSON array", encoded, len(encoded))
