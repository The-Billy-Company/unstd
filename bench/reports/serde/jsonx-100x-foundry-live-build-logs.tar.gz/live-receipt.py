from pathlib import Path
from hashlib import sha256
import json,struct,zipfile,xml.etree.ElementTree as ET,datetime,os
root=Path('/qualification');live=root/'live'
def digest(b):return sha256(b).hexdigest()
def sections(data):
 f=struct.unpack_from('<16sHHIQQQIHHHHHH',data);table=[struct.unpack_from('<IIQQQQIIQQ',data,f[6]+i*f[11]) for i in range(f[12])];s=table[f[13]];names=data[s[4]:s[4]+s[5]]
 return {names[s[0]:].split(b'\0',1)[0].decode():digest(data[s[4]:s[4]+s[5]]) for s in table if names[s[0]:].split(b'\0',1)[0] in (b'.text',b'.rodata')}
artifacts={}
for label,directory in [('wheel','wheel-live'),('sdist_wheel','wheel-live-rebuilt')]:
 p=next((root/directory).glob('*.whl'))
 with zipfile.ZipFile(p) as z:
  (name,)=[n for n in z.namelist() if n.startswith('unstd/serde/_json_native.') and n.endswith('.so')]
  artifacts[label]={'filename':p.name,'sha256':digest(p.read_bytes()),'native_member':name,'native_sha256':digest(z.read(name)),'native_elf_sections_sha256':sections(z.read(name)),'serde_python_sha256':{n:digest(z.read(n)) for n in z.namelist() if n.startswith('unstd/serde/') and n.endswith(('.py','.pyi'))}}
assert artifacts['wheel']['native_elf_sections_sha256']==artifacts['sdist_wheel']['native_elf_sections_sha256']
assert artifacts['wheel']['serde_python_sha256']==artifacts['sdist_wheel']['serde_python_sha256']
tests={}
for label,name in [('wheel','serde-live'),('sdist_wheel','serde-live-rebuilt')]:
 suite=ET.parse(root/f'{name}.xml').getroot().find('testsuite');tests[label]={'summary':suite.attrib,'log_sha256':digest((root/f'{name}.log').read_bytes())}
r={'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Current helper/module layout follow-up to final15a7 kernel qualification; same unchanged58caseharness and per-caseblock controller.','native_header_sha256':digest((live/'native/serde/src/repeat.h').read_bytes()),'source_sha256':{str(p.relative_to(live)):digest(p.read_bytes()) for folder in ('src/unstd/serde','native/serde') for p in sorted((live/folder).rglob('*')) if p.is_file() and p.suffix in ('.py','.pyi','.c','.h')},'extras_sha256':digest((live/'src/unstd/extras.py').read_bytes()),'layout_equivalence':json.loads((live/'compatibility-checks.json').read_text()),'build_inputs_sha256':{name:digest((live/name).read_bytes()) for name in ('pyproject.toml','hatch_build.py','uv.lock','tests/tooling/runtime/json_acceleration.py')},'artifacts':artifacts,'sdist_sha256':digest(next((root/'wheel-live').glob('*.tar.gz')).read_bytes()),'tests':tests,'preflight':{label:json.loads((root/f'{label}.json').read_text()) for label in ('smoke-live','smoke-live-rebuilt')},'benchmark_allocator':os.environ.get('PYTHONMALLOC','unset/default'),'benchmark_hash_seed':'0 (explicitcommand)','controller_sha256':digest((root/'interleaved.py').read_bytes()),'frozen_harness_sha256':digest((root/'combined/bench/profiles/jsonx_throughput.py').read_bytes()),'commands':(root/'live-check.sh').read_text(),'initial_retry_reason':'First live snapshot mixed refreshed build hook with stale compression native files; adding complete current native closure resolved missingnative/compress/src/fast.c. No product edit was made to repair the snapshot.'}
(root/'live-qualification.json').write_text(json.dumps(r,indent=2)+'\n')
