#!/bin/sh
set -eu
cd /qualification
CIBUILDWHEEL=1 uv build --python env/bin/python --no-build-isolation live --wheel --sdist --out-dir wheel-live > build-live.log 2>&1
CIBUILDWHEEL=1 uv build --python env/bin/python --no-build-isolation wheel-live/*.tar.gz --wheel --out-dir wheel-live-rebuilt > build-live-rebuilt.log 2>&1
uv pip install --python env/bin/python --no-deps --target installed-live wheel-live/*.whl > install-live.log 2>&1
uv pip install --python env/bin/python --no-deps --target installed-live-rebuilt wheel-live-rebuilt/*.whl > install-live-rebuilt.log 2>&1
uv pip install --python env/bin/python --no-deps --reinstall wheel-live/*.whl > install-env-live.log 2>&1
uv pip install --python env-rebuilt/bin/python --no-deps --reinstall wheel-live-rebuilt/*.whl > install-env-live-rebuilt.log 2>&1
PYTHONPATH=/qualification/installed-live env/bin/python live/tests/tooling/runtime/json_acceleration.py --json > smoke-live.json
PYTHONPATH=/qualification/installed-live-rebuilt env/bin/python live/tests/tooling/runtime/json_acceleration.py --json > smoke-live-rebuilt.json
PYTHONPATH=/qualification/live env/bin/python -m pytest live/tests/suites/product/serde -c live/pyproject.toml --require-extra serde -q --junitxml=serde-live.xml > serde-live.log 2>&1
PYTHONPATH=/qualification/live env-rebuilt/bin/python -m pytest live/tests/suites/product/serde -c live/pyproject.toml --require-extra serde -q --junitxml=serde-live-rebuilt.xml > serde-live-rebuilt.log 2>&1
PYTHONHASHSEED=0 env/bin/python interleaved.py --compare-source installed-prework --source installed-live --harness combined --include floats-256 --rounds 9 --repetitions 5 --output prework-live-shared.json > prework-live-shared.log 2>&1
