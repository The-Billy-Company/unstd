#!/bin/sh
set -eu
cd /qualification
export CIBUILDWHEEL=1
uv build --python env/bin/python --no-build-isolation combined --wheel --sdist --out-dir wheel-combined > build-combined-final.log 2>&1
uv build --python env/bin/python --no-build-isolation wheel-combined/*.tar.gz --wheel --out-dir wheel-rebuilt > build-rebuilt-final.log 2>&1
mkdir sdist
cp wheel-combined/*.tar.gz sdist/
uv pip install --python env/bin/python --no-deps --target installed-combined wheel-combined/*.whl > install-combined-final.log 2>&1
uv pip install --python env/bin/python --no-deps --target installed-rebuilt wheel-rebuilt/*.whl > install-rebuilt-final.log 2>&1
uv pip install --python env/bin/python --no-deps --reinstall wheel-combined/*.whl > install-env-final.log 2>&1
uv pip install --python env-rebuilt/bin/python --no-deps --reinstall wheel-rebuilt/*.whl > install-env-rebuilt-final.log 2>&1
PYTHONPATH=/qualification/installed-combined env/bin/python combined/tests/tooling/runtime/json_acceleration.py --json > smoke-combined.json
PYTHONPATH=/qualification/installed-rebuilt env/bin/python combined/tests/tooling/runtime/json_acceleration.py --json > smoke-rebuilt.json
PYTHONPATH=/qualification/combined env/bin/python -m pytest combined/tests/suites/product/serde -c combined/pyproject.toml --require-extra serde -q --junitxml=serde-combined.xml > serde-combined.log 2>&1
PYTHONPATH=/qualification/combined env-rebuilt/bin/python -m pytest combined/tests/suites/product/serde -c combined/pyproject.toml --require-extra serde -q --junitxml=serde-rebuilt.xml > serde-rebuilt.log 2>&1
export PYTHONHASHSEED=0
export PYTHONPATH=/qualification/combined
env/bin/python -m bench.profiles.jsonx_throughput --compare-source installed-prework --source installed-combined --require-native --rounds 7 --repetitions 3 --output prework-final-full.json > prework-final-full.log 2>&1
env/bin/python interleaved.py --compare-source installed-original --source installed-combined --harness combined --include floats-256 --rounds 9 --repetitions 5 --output original-final-shared.json > original-final-shared.log 2>&1
env/bin/python interleaved.py --compare-source installed-prework --source installed-combined --harness combined --include floats-256 --rounds 9 --repetitions 5 --output prework-final-shared.json > prework-final-shared.log 2>&1
env/bin/python scalar-probe.py --compare-source installed-prework --source installed-combined --harness combined --rounds 11 --repetitions 9 --output prework-final-scalars.json > prework-final-scalars.log 2>&1
env/bin/python interleaved.py --compare-source installed-combined --source installed-rebuilt --harness combined --include '' --rounds 9 --repetitions 5 --max-slowdown 1.15 --output final-rebuilt.json > final-rebuilt.log 2>&1
