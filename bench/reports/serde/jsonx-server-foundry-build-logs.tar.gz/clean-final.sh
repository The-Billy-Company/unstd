#!/bin/sh
set -eu
cd /qualification
mkdir -p transfer-initial
mv direct rebuilt installed-current installed-rebuilt smoke-direct.json smoke-rebuilt.json serde-direct.xml serde-rebuilt.xml build-direct.log build-rebuilt.log transfer-initial/
find current original -name '._*' -type f -delete
CIBUILDWHEEL=1 uv build --python env/bin/python --no-build-isolation current --wheel --sdist --out-dir direct > build-direct.log 2>&1
CIBUILDWHEEL=1 uv build --python env/bin/python --no-build-isolation direct/*.tar.gz --wheel --out-dir rebuilt > build-rebuilt.log 2>&1
uv pip install --python env/bin/python --no-deps --target installed-current direct/*.whl > install-current.log 2>&1
uv pip install --python env/bin/python --no-deps --target installed-rebuilt rebuilt/*.whl > install-rebuilt.log 2>&1
uv pip install --python env/bin/python --no-deps --reinstall direct/*.whl > install-env.log 2>&1
uv pip install --python env-rebuilt/bin/python --no-deps --reinstall rebuilt/*.whl > install-env-rebuilt.log 2>&1
PYTHONPATH=/qualification/installed-current env/bin/python current/tests/tooling/runtime/json_acceleration.py --json > smoke-direct.json
PYTHONPATH=/qualification/installed-rebuilt env/bin/python current/tests/tooling/runtime/json_acceleration.py --json > smoke-rebuilt.json
PYTHONPATH=/qualification/current env/bin/python -m pytest current/tests/suites/product/serde -c current/pyproject.toml --require-extra serde -q --junitxml=serde-direct.xml > serde-direct.log 2>&1
PYTHONPATH=/qualification/current env-rebuilt/bin/python -m pytest current/tests/suites/product/serde -c current/pyproject.toml --require-extra serde -q --junitxml=serde-rebuilt.xml > serde-rebuilt.log 2>&1
PYTHONHASHSEED=0 PYTHONPATH=/qualification/current env/bin/python -m bench.profiles.jsonx_throughput --compare-source installed-original --source installed-current --require-native --include records-1k --rounds 9 --repetitions 5 --output historical-current-clean-locked.json > historical-current-clean-locked.log 2>&1
PYTHONHASHSEED=0 PYTHONPATH=/qualification/current env/bin/python -m bench.profiles.jsonx_throughput --compare-source installed-current --source installed-rebuilt --require-native --include records-1k --rounds 9 --repetitions 5 --max-slowdown 1.15 --output wheel-sdist-clean-locked.json > wheel-sdist-clean-locked.log 2>&1
