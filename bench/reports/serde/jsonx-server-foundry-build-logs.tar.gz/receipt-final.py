from pathlib import Path
import json,runpy,hashlib,importlib.metadata as m,datetime,subprocess,struct,zipfile
root=Path('/qualification')
initial=json.loads((root/'qualification.json').read_text())
runpy.run_path(str(root/'receipt.py'))
r=json.loads((root/'qualification.json').read_text())
r['initial_qualification']=initial
r['build_environment']['backends']={name:m.version(name) for name in ('orjson','msgspec','pybase64','hatchling','setuptools')}
r['commands']['build_and_test_script']=(root/'clean-final.sh').read_text()
r['commands']['historical_profile']='PYTHONHASHSEED=0 PYTHONPATH=/qualification/current env/bin/python -m bench.profiles.jsonx_throughput --compare-source installed-original --source installed-current --require-native --include records-1k --rounds 9 --repetitions 5 --output historical-current-clean-locked.json'
r['commands']['packaging_profile']='PYTHONHASHSEED=0 PYTHONPATH=/qualification/current env/bin/python -m bench.profiles.jsonx_throughput --compare-source installed-current --source installed-rebuilt --require-native --include records-1k --rounds 9 --repetitions 5 --max-slowdown 1.15 --output wheel-sdist-clean-locked.json'
r['notes'] += ['Initial latest-backend transfer included AppleDouble metadata; final source directories and rebuilt direct/sdist wheels were cleaned before primary locked tests and profiles. Initial timings/receipt are preserved separately and real source bytes did not change.']
direct=next(v for n,v in r['artifacts'].items() if n.startswith('direct/') and n.endswith('.whl'))
rebuilt=next(v for n,v in r['artifacts'].items() if n.startswith('rebuilt/') and n.endswith('.whl'))
sdist=next(v for n,v in r['artifacts'].items() if n.startswith('direct/') and n.endswith('.tar.gz'))
expected={n.removeprefix('src/'):h for n,h in r['source_sha256'].items() if n.startswith('src/unstd/serde/')}
c_expected={n:h for n,h in r['source_sha256'].items() if n.startswith('native/serde/')}
sdist_sources={n.split('/',1)[1]:h for n,h in sdist['serde_native_sources'].items() if n.endswith(('.c','.h'))}
r['artifact_checks']={'both_wheels_match_current_python_sources':direct['serde_python_sha256']==rebuilt['serde_python_sha256']==expected,'sdist_has_complete_native_json_closure':sdist_sources==c_expected,'no_transfer_metadata_in_final_sources':not any(p.name.startswith('._') for p in (root/'current').rglob('*'))}
assert all(r['artifact_checks'].values()),r['artifact_checks']

def elf_sections(data):
 fields=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
 assert fields[0][:4]==b'\x7fELF' and fields[0][4:6]==b'\x02\x01'
 offset,entry,count,names=fields[6],fields[11],fields[12],fields[13]
 sections=[struct.unpack_from('<IIQQQQIIQQ',data,offset+i*entry) for i in range(count)]
 table=sections[names];strings=data[table[4]:table[4]+table[5]]
 out={}
 for section in sections:
  name=strings[section[0]:].split(b'\x00',1)[0].decode()
  if name in ('.text','.rodata'):
   out[name]=hashlib.sha256(data[section[4]:section[4]+section[5]]).hexdigest()
 return out
for folder,item in [('direct',direct),('rebuilt',rebuilt)]:
 wheel=next((root/folder).glob('*.whl'))
 with zipfile.ZipFile(wheel) as archive:
  item['elf_sections_sha256']=elf_sections(archive.read(item['json_native_member']))
r['artifact_checks']['identical_native_machine_code']=direct['elf_sections_sha256']['.text']==rebuilt['elf_sections_sha256']['.text']

r['cpu_stat_final']=subprocess.check_output(['cat','/sys/fs/cgroup/cpu.stat'],text=True)
r['reports']={name:{'sha256':hashlib.sha256((root/file).read_bytes()).hexdigest(),'cases':len(json.loads((root/file).read_text())['comparisons']),'environment':json.loads((root/file).read_text())['runs'][0]['environment']} for name,file in [('jsonx-server-foundry-py314.json','historical-current.json'),('jsonx-server-foundry-loads-py314.json','historical-loads.json'),('jsonx-server-foundry-packaging-py314.json','wheel-sdist.json'),('jsonx-server-foundry-py314-locked.json','historical-current-clean-locked.json'),('jsonx-server-foundry-packaging-py314-locked.json','wheel-sdist-clean-locked.json')]}
(root/'qualification-final.json').write_text(json.dumps(r,indent=2)+'\n')
