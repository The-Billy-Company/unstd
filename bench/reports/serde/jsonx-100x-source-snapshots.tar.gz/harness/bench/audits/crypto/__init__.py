"""Audits crypto benchmark tooling."""
