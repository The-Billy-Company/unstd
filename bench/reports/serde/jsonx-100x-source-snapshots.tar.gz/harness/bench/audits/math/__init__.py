"""Audits math benchmark tooling."""
