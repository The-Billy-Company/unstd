"""Audits benchmark tooling."""
