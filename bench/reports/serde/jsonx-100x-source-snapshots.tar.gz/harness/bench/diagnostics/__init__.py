"""Diagnostics benchmark tooling."""
