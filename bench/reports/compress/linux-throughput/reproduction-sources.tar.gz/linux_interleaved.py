"""Reproduce paired Billy timings on a busy host with persistent alternating workers."""
from __future__ import annotations
import argparse, gc, hashlib, importlib, json, os, platform, statistics, subprocess, sys
from pathlib import Path
from time import perf_counter_ns, thread_time_ns

def main():
 p=argparse.ArgumentParser();p.add_argument('--worker',type=Path);p.add_argument('--source',type=Path);p.add_argument('--baseline-source',type=Path);p.add_argument('--fixtures',type=Path,required=True);p.add_argument('--output',type=Path);p.add_argument('--rounds',type=int,default=11);p.add_argument('--batch-ms',type=int,default=30);a=p.parse_args()
 if a.worker:sys.path.insert(0,str(a.worker.resolve()))
 from bench.profiles import billy_gzip as b, gzip_reads as reads
 cases,_=b._load_fixtures(a.fixtures)
 if a.worker:
  sys.path.insert(0,str(a.worker.resolve()));codec=importlib.import_module('unstd.compress.gzipx')
  assert Path(codec.__file__).resolve()==a.worker.resolve()/'unstd/compress/gzipx.py'
  functions=[b._operation(codec,c) for c in cases]
  for c,f in zip(cases,functions):b._validate(codec,c,f())
  print(json.dumps({'metadata':reads._metadata(codec,[reads._Case(cases[0].name,cases[0].raw,cases[0].packed)]),'cases':[{'name':c.name,'raw_sha256':b._sha(c.raw),'packed_sha256':b._sha(c.packed),'native_calls':reads._native_calls(f),'selected_native_backends':reads._native_backends(codec,f)} for c,f in zip(cases,functions)]}),flush=True)
  for line in sys.stdin:
   r=json.loads(line);f=functions[r['case']];was=gc.isenabled();gc.disable()
   try:
    w=perf_counter_ns();t=thread_time_ns()
    for _ in range(r['iterations']): f()
    cpu=thread_time_ns()-t;wall=perf_counter_ns()-w
   finally:
    if was:gc.enable()
   b._validate(codec,cases[r['case']],f())
   print(json.dumps({'cpu_ns':cpu/r['iterations'],'wall_ns':wall/r['iterations'],'iterations':r['iterations']}),flush=True)
  return
 children={};records={};result={'schema':1,'method':'persistent workers; alternating per-case batches; common joint calibration; GC disabled; byte checks outside timing','rounds':a.rounds,'minimum_batch_cpu_ms':a.batch_ms,'loadavg_start':os.getloadavg(),'platform':platform.platform(),'python':sys.version,'harness_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'fixture_sha256':b._sha(a.fixtures.read_bytes())}
 def sample(n,i,it):
  child=children[n];child.stdin.write(json.dumps({'case':i,'iterations':it})+'\n');child.stdin.flush();line=child.stdout.readline()
  if not line:raise RuntimeError(f'{n} worker ended')
  return json.loads(line)
 try:
  for n,s in [('candidate',a.source),('baseline',a.baseline_source)]:
   c=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--worker',str(s),'--fixtures',str(a.fixtures)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True);children[n]=c;records[n]=json.loads(c.stdout.readline())
  result['records']=records;result['cases']=[]
  for i,case in enumerate(cases):
   for field in ('name','raw_sha256','packed_sha256'):
    assert records['candidate']['cases'][i][field]==records['baseline']['cases'][i][field]
   it=1;cal=[]
   while True:
    pilot={n:sample(n,i,it) for n in children};cal.append(pilot)
    if min(x['cpu_ns']*it for x in pilot.values())>=a.batch_ms*1e6:break
    it*=2;assert it<=1<<22
   samples={n:[] for n in children}
   for r in range(a.rounds):
    for n in (list(children) if r%2==0 else list(children)[::-1]): samples[n].append(sample(n,i,it))
   cpu=statistics.median(x['cpu_ns']/y['cpu_ns'] for x,y in zip(samples['baseline'],samples['candidate']));wall=statistics.median(x['wall_ns']/y['wall_ns'] for x,y in zip(samples['baseline'],samples['candidate']))
   result['cases'].append({'name':case.name,'samples':samples,'calibration':cal,'speedup_cpu':cpu,'speedup_wall':wall});print(case.name,round(cpu,3),round(wall,3),flush=True)
  result['loadavg_end']=os.getloadavg();result['regressions']=[c['name'] for c in result['cases'] if c['speedup_wall']<1/1.30]
  a.output.write_text(json.dumps(result,indent=2)+'\n');assert not result['regressions'],result['regressions']
 finally:
  for c in children.values():
   c.stdin.close()
   try:c.wait(timeout=10)
   except subprocess.TimeoutExpired:c.kill();c.wait()
if __name__=='__main__':main()
