"""Bounded-memory gzip member qualification above the 32-bit ISIZE boundary.

Run with the selected installation first on PYTHONPATH, for example:
  python3 unstd-final-large-gzip.py --output-dir /work/large-gzip
Only a compact gzip file and a small JSON receipt are retained.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import platform
from random import Random
import resource
import struct
import subprocess
import sys
from time import perf_counter
import zlib


CHUNK_BYTES = 256 * 1024
WRAP = 1 << 32
PREFIX_BYTES = 24576
TAIL_BYTES = 131072


def peak_rss_bytes() -> int:
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value if sys.platform == "darwin" else value * 1024)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while data := stream.read(65536):
            digest.update(data)
    return digest.hexdigest()


def generate(path: Path) -> dict[str, object]:
    started = perf_counter()
    prefix = Random(59231).randbytes(PREFIX_BYTES).translate(
        bytes(i & 31 for i in range(256))
    )
    encoder = zlib.compressobj(level=6, wbits=-15)
    prefix_wire = encoder.compress(prefix) + encoder.flush(zlib.Z_SYNC_FLUSH)
    if not (
        len(prefix_wire) >= 8192
        and prefix_wire[0] & 6 == 4
        and prefix_wire[1] & 31 >= 8
    ):
        raise RuntimeError("the initial stdlib dynamic block does not admit ISA-L")

    # A moderate repeated chunk is held once; no full member is materialized.
    pattern = b"large bounded gzip qualification: public synthetic bytes\n"
    chunk = (pattern * (CHUNK_BYTES // len(pattern) + 1))[:CHUNK_BYTES]
    crc = zlib.crc32(prefix)
    count = len(prefix)
    with path.open("xb") as stream:
        stream.write(b"\x1f\x8b\x08\x00" + bytes(6))
        stream.write(prefix_wire)
        for _ in range(WRAP // CHUNK_BYTES):
            stream.write(encoder.compress(chunk))
            crc = zlib.crc32(chunk, crc)
            count += len(chunk)
        tail = chunk[:TAIL_BYTES]
        stream.write(encoder.compress(tail))
        crc = zlib.crc32(tail, crc)
        count += len(tail)
        stream.write(encoder.flush(zlib.Z_FINISH))
        stream.write(struct.pack("<II", crc & 0xFFFFFFFF, count & 0xFFFFFFFF))
    if count <= WRAP:
        raise RuntimeError("fixture did not cross 4 GiB")
    with path.open("rb") as stream:
        stream.seek(-8, 2)
        trailer_crc, trailer_isize = struct.unpack("<II", stream.read(8))
    if (trailer_crc, trailer_isize) != (crc & 0xFFFFFFFF, count % WRAP):
        raise RuntimeError("gzip trailer does not match generated count and CRC")
    return {
        "uncompressed_bytes": count,
        "crc32": crc & 0xFFFFFFFF,
        "isize": trailer_isize,
        "wrap_count": count // WRAP,
        "compressed_bytes": path.stat().st_size,
        "compressed_sha256": file_sha256(path),
        "prefix_uncompressed_bytes": len(prefix),
        "prefix_compressed_bytes": len(prefix_wire),
        "prefix_btype": (prefix_wire[0] >> 1) & 3,
        "prefix_hlit_gate": prefix_wire[1] & 31,
        "generation_chunk_bytes": len(chunk),
        "elapsed_seconds": perf_counter() - started,
        "peak_rss_bytes": peak_rss_bytes(),
    }


def worker(codec: str, path: Path, expected_size: int, expected_crc: int) -> None:
    started = perf_counter()
    from zlib_ng import zlib_ng as ng

    if codec == "candidate":
        from unstd.compress import gzipx as provider
        from unstd.compress import _gzip_native as native

        if not getattr(native, "ISAL_STREAMING", False):
            raise RuntimeError("candidate has no ISA-L streaming capability")
        if native.ISAL_PATCH_SHA256 != "9b537e1df67e96f78bd683db3d2d2c6de9709398687b7e4c3f6a043686baf905":
            raise RuntimeError("candidate does not contain the frozen final ISA-L core")
        native_metadata = {
            "path": native.__file__,
            "sha256": file_sha256(Path(native.__file__)),
            "isa_l_version": native.ISAL_RUNTIME_VERSION,
            "isa_l_patch_sha256": native.ISAL_PATCH_SHA256,
        }
    else:
        from zlib_ng import gzip_ng as provider

        native_metadata = None
    engines: set[str] = set()
    checkpoints = []
    count = crc = calls = 0
    with provider.GzipFile(filename=str(path), mode="rb") as stream:
        while True:
            data = stream.read(CHUNK_BYTES)
            calls += 1
            if codec == "candidate":
                decoder = getattr(getattr(stream._buffer, "raw", None), "_decompressor", None)
                engines.add(str(getattr(decoder, "_selected_backend", None)))
            if not data:
                break
            if len(data) > CHUNK_BYTES:
                raise RuntimeError("provider exceeded the explicit read budget")
            count += len(data)
            crc = zlib.crc32(data, crc)
            if WRAP - CHUNK_BYTES <= count <= WRAP + 2 * CHUNK_BYTES:
                checkpoints.append({"bytes": count, "crc32": crc & 0xFFFFFFFF})
    crc &= 0xFFFFFFFF
    if (count, crc) != (expected_size, expected_crc):
        raise RuntimeError(f"decoded count/CRC changed: {(count, crc)}")
    if codec == "candidate" and "isal" not in engines:
        raise RuntimeError(f"candidate did not exercise ISA-L: {sorted(engines)}")
    print(json.dumps({
        "status": "passed",
        "codec": codec,
        "provider_path": provider.__file__,
        "ng_version": getattr(ng, "ZLIBNG_RUNTIME_VERSION", None),
        "native": native_metadata,
        "read_budget_bytes": CHUNK_BYTES,
        "read_calls": calls,
        "decoded_bytes": count,
        "crc32": crc,
        "selected_engines": sorted(engines),
        "wrap_checkpoints": checkpoints,
        "elapsed_seconds": perf_counter() - started,
        "peak_rss_bytes": peak_rss_bytes(),
    }, sort_keys=True))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--worker", choices=("candidate", "baseline"))
    parser.add_argument("--gzip-file", type=Path)
    parser.add_argument("--expected-size", type=int)
    parser.add_argument("--expected-crc", type=int)
    args = parser.parse_args()
    if args.worker:
        worker(args.worker, args.gzip_file, args.expected_size, args.expected_crc)
        return
    if args.output_dir is None:
        parser.error("--output-dir is required")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    path = args.output_dir / "large-isize-wrap.gz"
    fixture = generate(path)
    records = {}
    for codec in ("baseline", "candidate"):
        command = [
            sys.executable, str(Path(__file__).resolve()), "--worker", codec,
            "--gzip-file", str(path.resolve()),
            "--expected-size", str(fixture["uncompressed_bytes"]),
            "--expected-crc", str(fixture["crc32"]),
        ]
        process = subprocess.run(command, capture_output=True, text=True, timeout=900)
        if process.returncode == 0:
            records[codec] = json.loads(process.stdout)
        else:
            records[codec] = {
                "status": "failed", "returncode": process.returncode,
                "stdout": process.stdout[-8192:], "stderr": process.stderr[-8192:],
            }
    report = {
        "status": "passed" if all(r["status"] == "passed" for r in records.values()) else "failed",
        "python": sys.version,
        "platform": platform.platform(),
        "script_sha256": file_sha256(Path(__file__)),
        "fixture_path": str(path.resolve()),
        "fixture": fixture,
        "decoders": records,
        "contract": "One valid gzip member, >4 GiB recovered, wrapped ISIZE, bounded 256 KiB reads; count and CRC independently compared with generated input and NG baseline.",
    }
    output = args.output_dir / "large-isize-wrap.json"
    output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": report["status"], "report": str(output), "uncompressed_bytes": fixture["uncompressed_bytes"], "compressed_bytes": fixture["compressed_bytes"]}))
    if report["status"] != "passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
