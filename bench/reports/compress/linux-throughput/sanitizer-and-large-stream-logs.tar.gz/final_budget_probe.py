"""Independent stored/fixed/dynamic budget and source-history differential probes."""
import argparse,ast,gzip,hashlib,importlib.util,io,json,random,struct,zlib
from pathlib import Path
from zlib_ng import zlib_ng as ng
from unstd.compress import gzipx
from unstd.compress.engines import reader as _reader
parser=argparse.ArgumentParser();parser.add_argument('--prototype',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
spec=importlib.util.spec_from_file_location('budget_probe._gzip_native',args.prototype);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);assert module._configure_ng(ng.__file__)
candidate=module.Inflater
SOURCE=Path('/work/source-final/tests/suites/product/compress/unit/test_native_adaptive.py');space={}
for node in ast.parse(SOURCE.read_text()).body:
 if isinstance(node,(ast.ClassDef,ast.FunctionDef)) and node.name in ('_Bits','_dynamic'):exec(compile(ast.Module(body=[node],type_ignores=[]),'<independentRFC1951fixture>','exec'),space)
Bits=space['_Bits'];dynamic=space['_dynamic']
def digest(data):return hashlib.sha256(data).hexdigest()
def fixed_symbol(bits,symbol):
 if symbol<=143:bits.code(symbol+48,8)
 elif symbol<=255:bits.code(symbol-144+400,9)
 elif symbol<=279:bits.code(symbol-256,7)
 else:bits.code(symbol-280+192,8)
def stored(n,bad=False):
 raw=(b'prefix fixture\n'*(n//15+1))[:n];wire=bytes([0 if bad else 1])+struct.pack('<HH',n,n^65535)+raw
 return wire+(b'\x07' if bad else b''),raw

def fixed(n,bad=False,match=False,invalid_distance=False):
 b=Bits();b.little(not bad,1);b.little(1,2);raw=b'a'
 fixed_symbol(b,97)
 if invalid_distance:
  for _ in range(max(0,n-1)):fixed_symbol(b,97)
  raw=b'a'*max(n,1)
  fixed_symbol(b,285);b.code(31,5)
 elif match:
  for _ in range(n):fixed_symbol(b,285);b.code(0,5)
  raw+=b'a'*(258*n)
 else:
  for _ in range(max(0,n-1)):fixed_symbol(b,97)
  raw=b'a'*max(n,1)
 if not invalid_distance:fixed_symbol(b,256)
 if bad:b.little(1,1);b.little(3,2)
 return b.finish(),raw

def dyn(matches,bad=False):
 wire,raw,header=dynamic(long_matches=matches)
 if bad:
  count=header+2+2*matches+2;b=Bits();b.bits=[(wire[i//8]>>(i%8))&1 for i in range(count)];b.bits[0]=0;b.little(1,1);b.little(3,2);wire=b.finish()
 return wire,raw

cases=[]
for n in (0,1,7,31,255,1024,8192,9216,16384,32768,65535):
 for bad in (False,True):
  wire,raw=stored(n,bad);cases.append((f'stored-{n}-bad{bad}',wire,raw,bad))
for n in (1,7,31,255,1024,8192,9216,32768,65535):
 for bad in (False,True):
  wire,raw=fixed(n,bad);cases.append((f'fixed-literals-{n}-bad{bad}',wire,raw,bad))
for n in (0,1,7,31,64,127):
 for bad in (False,True):
  wire,raw=fixed(n,bad,True);cases.append((f'fixed-matches-{n}-bad{bad}',wire,raw,bad))
  wire,raw=dyn(n,bad);cases.append((f'dynamic-matches-{n}-bad{bad}',wire,raw,bad))
for n in (1,2,3,4,7,31):
 wire,raw=fixed(n,True,invalid_distance=True);cases.append((f'fixed-reserved-distance-{n}',wire,raw,True))
 b=Bits();b.little(1,1);b.little(1,2)
 for _ in range(n):fixed_symbol(b,97)
 fixed_symbol(b,286);cases.append((f'fixed-reserved-length-{n}',b.finish(),b'a'*n,True))
# A valid stored prefix forces the large-input/output ISA route before tiny tails.
prefix_raw=random.Random(59231).randbytes(24576).translate(bytes(i&31 for i in range(256)))
prefix_encoder=ng.compressobj(wbits=-15)
prefix=prefix_encoder.compress(prefix_raw)+prefix_encoder.flush(ng.Z_SYNC_FLUSH)
assert (prefix[0]&6)==4 and (prefix[1]&31)>=8 and len(prefix)>=8192, (prefix[:2].hex(),len(prefix))
cases += [(f'admitted:{name}',prefix+wire,prefix_raw+raw,bad) for name,wire,raw,bad in cases.copy()]
rng=random.Random(0x1951)
seed_cases=cases.copy()
for index in range(240):
 name,wire,raw,bad=rng.choice(seed_cases)
 if not wire:continue
 changed=bytearray(wire);position=rng.randrange(len(changed));changed[position]^=1<<rng.randrange(8)
 cases.append((f'bitdamage-{index}:{name}',bytes(changed),raw,True))
for name,wire,raw,bad in seed_cases:
 for cut in sorted({0,1,max(0,len(wire)//2),max(0,len(wire)-1)}):cases.append((f'truncate-{cut}:{name}',wire[:cut],raw,True))

def norm_error(exc):
 name='zlib.error' if isinstance(exc,(zlib.error,ng.error)) else type(exc).__module__+'.'+type(exc).__name__
 return name,str(exc)

def trace(factory,wire,program,chunk):
 d=factory(wbits=-15);position=0;outputs=[];engines=set();hasher=hashlib.sha256();count=0;error=None;stop='limit'
 for step in range(96):
  incoming=b''
  if d.needs_input:
   incoming=wire[position:position+chunk];position+=len(incoming)
  budget=program[min(step,len(program)-1)]
  try:value=d.decompress(incoming,budget)
  except Exception as exc:engines.add(getattr(d,'_selected_backend',None));error=norm_error(exc);stop='error';break
  engines.add(getattr(d,'_selected_backend',None))
  count+=len(value);hasher.update(value)
  outputs.append((len(value),digest(value),bool(d.eof),bool(d.needs_input),len(d.unused_data),digest(d.unused_data)))
  if d.eof:stop='eof';break
  if not value and d.needs_input and position==len(wire):stop='input';break
 return {'outputs':outputs,'delivered':count,'delivered_sha256':hasher.hexdigest(),'error':error,'source_position':position,'stop':stop,'engines':sorted(str(e) for e in engines)}

def structural(value):
 result=dict(value);result.pop('engines',None)
 return result

def programs(n):
 return [('16k-8k',[16384,8192,8192]),('large',[131072]*4),('before',[max(1,n-1),1,1]),('exact',[max(1,n),1,1]),('above',[max(1,n+1),1]),('byte-tail',[max(1,n-16)]+[1]*33),('seven-tail',[7,max(1,n-16)]+[7]*33),('8k',[8192]*32)]

rows=[];mismatches=[];diagnostics=[];engines={}
for name,wire,raw,bad in cases:
 if not bad:assert zlib.decompress(wire,-15)==raw,name
 for label,program in programs(len(raw)):
  for chunk in (len(wire)+1,16384):
   before=trace(ng._ZlibDecompressor,wire,program,chunk);after=trace(candidate,wire,program,chunk)
   for engine in after['engines']: engines[engine]=engines.get(engine,0)+1
   if before['error']!=after['error'] and before['error'] is not None and after['error'] is not None:diagnostics.append({'case':name,'program':label,'baseline':before['error'],'candidate':after['error']})
   row={'case':name,'program':label,'chunk':chunk,'wire_sha256':digest(wire),'output_size_hint':len(raw)}
   if structural(before)!=structural(after):mismatches.append({**row,'baseline':before,'candidate':after})
   else:rows.append(row)

class Fault(RuntimeError):pass
class Source(io.BytesIO):
 def __init__(self,data,chunk,fault):super().__init__(data);self.chunk=chunk;self.fault=fault;self.calls=[];self.failure=Fault('owned source failure')
 def read(self,n=-1):
  if len(self.calls)+1==self.fault:self.calls.append((n,'fault'));raise self.failure
  cap=16384 if self.chunk==73 and n>=1024 and not any(call[0]>=1024 for call in self.calls) else self.chunk
  result=super().read(min(n,cap) if n>=0 else cap);self.calls.append((n,len(result)));return result

def public(factory,data,method,budget,chunk,fault):
 _reader._factory=factory;s=Source(data,chunk,fault);result=[];buffer=bytearray([0xa5])*budget;error=None;identity=None
 try:
  with gzipx.GzipFile(fileobj=s) as f:
   result.append(f.read1(16384))
   for _ in range(100000):
    if method=='readinto':
     used=f.readinto(buffer);value=bytes(buffer[:used])
    else:value=getattr(f,method)(budget)
    if not value:break
    result.append(value)
   else:raise AssertionError('public did not terminate')
 except Exception as exc:error=norm_error(exc);identity=exc is s.failure if isinstance(exc,Fault) else None
 return {'delivered':len(b''.join(result)),'delivered_sha256':digest(b''.join(result)),'pieces':[len(p) for p in result],'error':error,'fault_identity':identity,'calls':s.calls,'source_position':s.tell(),'source_open':not s.closed,'failed_buffer_sha256':digest(buffer)}

public_rows=[];public_mismatches=[];original=_reader._factory;first=gzip.compress(b'first member\n'*30,mtime=0)
try:
 for name,wire,raw,bad in seed_cases:
  member=b'\x1f\x8b\x08\x00'+bytes(6)+wire+struct.pack('<II',zlib.crc32(raw),len(raw))
  for later in (False,True):
   packed=first+member if later else member
   for method,budget in [('read',7),('read',8192),('read1',7),('read1',32768),('readinto',7),('readinto',8192)]:
    for chunk in (len(packed)+1,73):
     for fault in (0,4):
      before=public(ng._ZlibDecompressor,packed,method,budget,chunk,fault);after=public(candidate,packed,method,budget,chunk,fault)
      row={'case':name,'later_member':later,'method':method,'budget':budget,'chunk':chunk,'fault':fault}
      if structural(before)!=structural(after):public_mismatches.append({**row,'baseline':before,'candidate':after})
      else:public_rows.append(row)
finally:_reader._factory=original
report={'raw_engine_counts':engines,'diagnostic_mismatches':diagnostics,'prototype':str(args.prototype),'prototype_sha256':digest(args.prototype.read_bytes()),'fixture_source_sha256':digest(SOURCE.read_bytes()),'ng_version':ng.ZLIBNG_RUNTIME_VERSION,'raw_cases':len(cases),'raw_traces':len(rows)+len(mismatches),'raw_mismatches':mismatches,'public_traces':len(public_rows)+len(public_mismatches),'public_mismatches':public_mismatches,'comparison':'Require exact error family and wording, bytes/call boundaries, input state/source callbacks/failure ownership'}
args.output.write_text(json.dumps(report,indent=2)+'\n');print('diagnostic',len(diagnostics),'engines',engines);print('raw',len(mismatches),'/',report['raw_traces'],'public',len(public_mismatches),'/',report['public_traces'])
for r in mismatches[:4]:print('RAW',r['case'],r['program'],r['chunk'],'delivered',r['baseline']['delivered'],r['candidate']['delivered'],'steps',len(r['baseline']['outputs']),len(r['candidate']['outputs']))
for r in public_mismatches[:4]:print('PUBLIC',r['case'],r['method'],r['budget'],'delivered',r['baseline']['delivered'],r['candidate']['delivered'],'sourcecalls',len(r['baseline']['calls']),len(r['candidate']['calls']))
