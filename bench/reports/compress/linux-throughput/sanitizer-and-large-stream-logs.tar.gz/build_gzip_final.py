"""Build only the task's private gzip extension over an isolated installation."""
import argparse
from importlib.util import module_from_spec,spec_from_file_location
import os
from pathlib import Path
import shutil
from tempfile import TemporaryDirectory

parser=argparse.ArgumentParser()
parser.add_argument('--root',type=Path,required=True)
parser.add_argument('--before',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
root=args.root.resolve(); output=args.output.resolve()
assert not output.exists(),output
assert os.environ.get('UNSTD_GZIP_ZLIB_RS') is None
shutil.copytree(args.before,output)
shutil.rmtree(output/'unstd/compress')
shutil.copytree(root/'src/unstd/compress',output/'unstd/compress',ignore=shutil.ignore_patterns('__pycache__','*.so','*.pyd','*.pyc'),dirs_exist_ok=True)
spec=spec_from_file_location('gzip_build_hook',root/'hatch_build.py')
module=module_from_spec(spec);spec.loader.exec_module(module)
with TemporaryDirectory(prefix='unstd-gzip-build-') as temporary:
    hook=module.CustomBuildHook(str(root),{},None,None,temporary,'wheel')
    data={'force_include':{}}
    hook._build_module('unstd.compress._gzip_native',Path(temporary),'standard',data)
    assert len(data['force_include'])==1
    for source,target in data['force_include'].items():
        destination=output/target
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,destination)
print(output)
