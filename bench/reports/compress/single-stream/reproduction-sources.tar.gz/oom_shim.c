#include <stdint.h>
#include <stdatomic.h>
#include <dlfcn.h>
static int32_t(*init_fn)(void*,int32_t,const char*,int32_t);
static int32_t(*decode_fn)(void*,int32_t);
static int32_t(*end_fn)(void*);
static const char*(*version_fn)(void);
static _Atomic int fail;
static _Atomic unsigned decodes;
static void *owner;
int bind_provider(const char*p){owner=dlopen(p,RTLD_LAZY|RTLD_LOCAL|RTLD_NOLOAD);if(!owner)return 0;init_fn=(int32_t(*)(void*,int32_t,const char*,int32_t))dlsym(owner,"zng_inflateInit2_");decode_fn=(int32_t(*)(void*,int32_t))dlsym(owner,"zng_inflate");end_fn=(int32_t(*)(void*))dlsym(owner,"zng_inflateEnd");version_fn=(const char*(*)(void))dlsym(owner,"zlibng_version");return init_fn&&decode_fn&&end_fn&&version_fn;}
void fail_next_init(void){atomic_store(&fail,1);}
unsigned decode_calls(void){return atomic_load(&decodes);}
const char*zlibng_version(void){return version_fn();}
int32_t zng_inflateInit2_(void*s,int32_t w,const char*v,int32_t n){if(atomic_exchange(&fail,0))return -4;return init_fn(s,w,v,n);}
int32_t zng_inflate(void*s,int32_t f){atomic_fetch_add(&decodes,1);return decode_fn(s,f);}
int32_t zng_inflateEnd(void*s){return end_fn(s);}
