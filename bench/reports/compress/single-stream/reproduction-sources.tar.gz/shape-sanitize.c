#include "shape.h"
#include "seed.h"
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
static uint32_t state = 71523;
static uint32_t random_word(void) {
    state ^= state << 13; state ^= state >> 17; state ^= state << 5;
    return state;
}
static unsigned int reference(uint32_t hold,unsigned int bits,unsigned int pair,unsigned int width) {
    unsigned int n = 0;
    while (n < bits / width && ((hold >> (n * width)) & ((1U << width) - 1U)) == pair) ++n;
    return n;
}
int main(void) {
    unsigned int calls = 0, math = 0;
    for (unsigned int width = 2; width <= 11; ++width) {
        for (unsigned int pair = 0; pair < (1U << width); ++pair) {
            uint32_t tiled = 0;
            for (unsigned int shift = 0; shift < 32; shift += width) tiled |= pair << shift;
            for (unsigned int bits = 0; bits < 32; ++bits) {
                uint32_t hold = tiled ^ (UINT32_C(1) << (random_word() % 32));
                if (unstd_cl_groups(hold,bits,pair,width) != reference(hold,bits,pair,width)) return 4;
                ++math;
            }
        }
    }
    size_t page = (size_t)sysconf(_SC_PAGESIZE);
    size_t usable = ((8193 + page - 1) / page) * page;
    unsigned char *region = mmap(NULL, usable + page, PROT_READ | PROT_WRITE,
                                MAP_PRIVATE | MAP_ANON, -1, 0);
    if (region == MAP_FAILED || mprotect(region + usable, page, PROT_NONE) != 0) return 2;
    for (unsigned int size = 0; size <= 512; ++size) {
        unsigned char *data = region + usable - size;
        for (unsigned int iteration = 0; iteration < 256; ++iteration) {
            for (unsigned int i = 0; i < size; ++i) data[i] = (unsigned char)random_word();
            if (size >= 2 && iteration % 2) { data[0] = 0xed; data[1] &= 7; }
            (void)unstd_prefer_ng(data, size); ++calls;
        }
    }
    for (unsigned int size = 0; size <= sizeof(seed); ++size) {
        unsigned char *data = region + usable - size;
        memcpy(data, seed, size);
        (void)unstd_prefer_ng(data, size); ++calls;
        if (size != sizeof(seed) && size != sizeof(seed) - 1 && size != sizeof(seed) / 2) continue;
        for (unsigned int byte = 0; byte < size; ++byte) {
            for (unsigned int bit = 0; bit < 8; ++bit) {
                data[byte] ^= (unsigned char)(1U << bit);
                (void)unstd_prefer_ng(data, size); ++calls;
                data[byte] ^= (unsigned char)(1U << bit);
            }
        }
    }
    for (unsigned int size = 8191; size <= 8193; ++size) {
        unsigned char *data = region + usable - size;
        memset(data, 0, size);
        memcpy(data, seed, sizeof(seed));
        if (unstd_prefer_ng(data, size) != (size <= 8192)) return 3;
        ++calls;
    }
    munmap(region, usable + page);
    printf("%u guard-page calls, %u group-math cases, no ASan/UBSan error\n", calls, math);
    return 0;
}
