#include "shape.h"
int classify(const unsigned char *data,uint32_t size){return unstd_prefer_ng(data,size);}
unsigned int groups(uint32_t hold,unsigned int bits,unsigned int pair,unsigned int width){return unstd_cl_groups(hold,bits,pair,width);}
