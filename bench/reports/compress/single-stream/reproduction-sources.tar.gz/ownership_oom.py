import ctypes,importlib,zlib,gc,json
from pathlib import Path
from zlib_ng import zlib_ng
n=importlib.import_module('unstd.compress._gzip_native');assert n._ng_runtime_version() is None
shim=ctypes.CDLL('/tmp/unstd-codec-final-receipts/oom_shim.dylib');shim.bind_provider.argtypes=[ctypes.c_char_p];shim.bind_provider.restype=ctypes.c_int
assert shim.bind_provider(zlib_ng.__file__.encode())
old=n.Inflater();assert old._selected_backend=='apple'
shim.fail_next_init()
try:n._configure_ng('/tmp/unstd-codec-final-receipts/oom_shim.dylib')
except MemoryError:pass
else:raise AssertionError('probe allocation failure was hidden')
assert n._ng_runtime_version() is None
assert n._configure_ng('/tmp/unstd-codec-final-receipts/oom_shim.dylib')
raw=b'a'*1000000;body=zlib.compress(raw,wbits=-15)
assert old.decompress(body,16384)==raw[:16384];assert old._selected_backend=='apple'
d=n.Inflater();before=shim.decode_calls();shim.fail_next_init()
try:d.decompress(body,16384)
except MemoryError:pass
else:raise AssertionError('stream init allocation failure was hidden')
assert d._selected_backend=='pending' and not d.eof and shim.decode_calls()==before
parts=[d.decompress(b'',16384)];assert d._selected_backend=='ng'
while not d.eof:parts.append(d.decompress(b'',16384))
assert b''.join(parts)==raw and d.unused_data==b''
result={'native':n.__file__,'abi_version':n._ng_runtime_version(),'probe_oom_unconfigured':True,'old_stream_stays_apple':True,'stream_init_oom_before_decode':True,'retry_retains_complete_input':True}
Path('/tmp/unstd-codec-final-receipts/ownership-oom-final16.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
