import ast,gc,gzip,importlib.util,io,json,statistics,struct,sys,time,zlib
from pathlib import Path
ROOT=Path('dependency-source/unstd');OUT=Path('/tmp/unstd-codec-final-receipts')
from unstd.compress import gzipx,_reader,_gzip_native as candidate
basepath=next(Path('/tmp/unstd-single-root/before-qualified/unstd/compress').glob('_gzip_native*.so'))
spec=importlib.util.spec_from_file_location('qualified_before._gzip_native',basepath);baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
space={};tree=ast.parse((ROOT/'tests/suites/product/compress/unit/test_native_adaptive.py').read_text())
for node in tree.body:
 if isinstance(node,(ast.ClassDef,ast.FunctionDef)) and node.name in ['_Bits','_dynamic']:exec(compile(ast.Module(body=[node],type_ignores=[]),'<independent-unit-fixtures>','exec'),space)
def fixture(matches,literals=1,alternating=False):
 _,_,header=space['_dynamic'](long_matches=0)
 body,_,_=space['_dynamic'](long_matches=0)
 b=space['_Bits']();b.bits=[(body[i//8]>>(i%8))&1 for i in range(header)]
 first=2 if alternating else 1
 for _ in range(first):b.code(2,2)
 for i in range(matches):b.code(0,1);b.code(i%2 if alternating else 0,1)
 for _ in range(literals-first):b.code(2,2)
 b.code(3,2);body=b.finish();raw=b'a'*(258*matches+literals)
 assert zlib.decompress(body,wbits=-15)==raw
 return b'\x1f\x8b\x08\x00'+bytes(6)+body+struct.pack('<II',zlib.crc32(raw),len(raw)),raw
cases=[]
for name,matches,literals,alternating in [('min64long',64,1,False),('long4000',4000,1,False),('long4000-literal32',4000,32,False),('long4000-literal33',4000,33,False),('long4096-token-cap',4096,1,False),('alternating-long4000',4000,2,True),('alternating-long4000-literal33',4000,33,True),('alternating-token-cap',4096,2,True)]:
 wire,raw=fixture(matches,literals,alternating);cases.append((name,wire,raw))
for name,raw in [('tiny',b'hello world'),('empty',b''),('spaces1m',b' '*1000000)]:cases.append((name,gzip.compress(raw,mtime=0),raw))
def operation(wire):
 with gzipx.GzipFile(fileobj=io.BytesIO(wire)) as reader:return reader.read(8192)
rows=[];original=_reader._factory
try:
 for name,wire,raw in cases:
  for label,module in [('apple',baseline),('candidate',candidate)]:
   _reader._factory=module.Inflater;assert operation(wire)==raw[:8192]
  _reader._factory=candidate.Inflater
  with gzipx.GzipFile(fileobj=io.BytesIO(wire)) as f:
   d=f._buffer.raw._decompressor;assert f.read(8192)==raw[:8192];selected=d._selected_backend
  samples={name:[] for name in ['apple','candidate']};gc.disable()
  try:
   for rep in range(21):
    order=['apple','candidate'] if rep%2==0 else ['candidate','apple']
    for label in order:
     _reader._factory=baseline.Inflater if label=='apple' else candidate.Inflater;start=time.thread_time_ns()
     for _ in range(128):operation(wire)
     samples[label].append((time.thread_time_ns()-start)/128)
  finally:gc.enable()
  med={label:statistics.median(v) for label,v in samples.items()};row={'name':name,'wire_bytes':len(wire),'raw_bytes':len(raw),'read_size':8192,'selected':selected,'median_cpu_ns':med,'slowdown':med['candidate']/med['apple'],'extra_cpu_ns':med['candidate']-med['apple'],'samples_cpu_ns':samples};rows.append(row)
  print(name,selected,'slowdown',round(row['slowdown'],3),'extra_us',round(row['extra_cpu_ns']/1000,3),flush=True)
finally:_reader._factory=original
(OUT/'edges-final16.json').write_text(json.dumps({'candidate':candidate.__file__,'baseline':str(basepath),'ng_version':candidate._ng_runtime_version(),'cases':rows},indent=2)+'\n')
