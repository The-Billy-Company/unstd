import ctypes,gc,importlib,sys,weakref,zlib,json
from pathlib import Path
from zlib_ng import zlib_ng
import unstd.compress as package
module=importlib.import_module('unstd.compress._gzip_native');assert module._configure_ng(zlib_ng.__file__)
body=zlib.compress(b' '*1000000,wbits=-15);d=module.Inflater();assert d.decompress(body,16384)==b' '*16384;assert d._selected_backend=='ng' and gc.is_tracked(d)
# Preserve a live instance after exports disappear, then construct a collectible cycle.
kind=type(d);saved_name=module.__name__;module_name=module.__file__
sys.modules.pop(saved_name,None);vars(package).pop('_gzip_native',None)
module.__dict__.clear();assert d.decompress(b'',16384)==b' '*16384
d.__init__();assert d.decompress(body,16384)==b' '*16384
holder=[];holder.append(holder);holder.append(d);module._held=holder
owner=weakref.ref(module);type_ref=weakref.ref(kind)
getdef=ctypes.pythonapi.PyModule_GetDef;getdef.argtypes=[ctypes.py_object];getdef.restype=ctypes.c_void_p
remove=ctypes.pythonapi.PyState_RemoveModule;remove.argtypes=[ctypes.c_void_p];remove.restype=ctypes.c_int
assert remove(getdef(module))==0
del d,holder,module,kind
for _ in range(3):gc.collect()
assert owner() is None and type_ref() is None
result={'native':module_name,'live_after_exports_clear':True,'reinit_after_exports_clear':True,'module_instance_type_cycle_collected':True,'allocator':'debug'}
Path('/tmp/unstd-codec-final-receipts/gc-cycle-final16.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
