from __future__ import annotations
import base64,collections,ctypes,gzip,hashlib,io,json,random,runpy,zlib
from pathlib import Path
root=Path('/Users/griffinstrier/Billy-Company/unstd');out=Path(__file__).parent
lib=ctypes.CDLL(str(out/'classify.dylib'));lib.classify.argtypes=[ctypes.c_char_p,ctypes.c_uint32];lib.classify.restype=ctypes.c_int
lib.groups.argtypes=[ctypes.c_uint32]*4;lib.groups.restype=ctypes.c_uint

def classify(data):return bool(lib.classify(bytes(data),len(data)))
class Rejected(Exception):pass
class Reader:
 def __init__(self,data):self.data=data;self.position=0
 def get(self,n):
  if self.position+n>8*len(self.data):raise Rejected
  value=sum(((self.data[(self.position+i)//8]>>((self.position+i)%8))&1)<<i for i in range(n));self.position+=n;return value
class Tree:
 def __init__(self,lengths,maximum):
  counts=collections.Counter(lengths);left=1
  for bits in range(1,maximum+1):
   left=left*2-counts[bits]
   if left<0:raise Rejected
  if left:raise Rejected
  code=0;previous=0;self.codes={};self.maximum=maximum
  for n,symbol in sorted((n,s) for s,n in enumerate(lengths) if n):
   code<<=n-previous;self.codes[(code,n)]=symbol;code+=1;previous=n
 def get(self,r):
  code=0
  for n in range(1,self.maximum+1):
   code=(code<<1)|r.get(1)
   if (code,n) in self.codes:return self.codes[(code,n)]
  raise Rejected

def reference(data):
 if len(data)>8192:return False
 r=Reader(data)
 try:
  final=r.get(1);kind=r.get(2);nlit=r.get(5)+257;ndist=r.get(5)+1;npre=r.get(4)+4
  if final!=1 or kind!=2 or nlit!=286 or ndist>8:return False
  order=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];pre=[0]*19
  for i in range(npre):pre[order[i]]=r.get(3)
  pre=Tree(pre,7);lengths=[]
  while len(lengths)<nlit+ndist:
   symbol=pre.get(r)
   if symbol<16:lengths.append(symbol)
   elif symbol==16:
    if not lengths:return False
    lengths.extend([lengths[-1]]*(3+r.get(2)))
   elif symbol==17:lengths.extend([0]*(3+r.get(3)))
   else:lengths.extend([0]*(11+r.get(7)))
   if len(lengths)>nlit+ndist:return False
  if not lengths[256] or not 1<=lengths[285]<=2 or sum(bool(x) for x in lengths[:256])>16:return False
  ll=Tree(lengths[:286],15);dist=Tree(lengths[286:],15)
  produced=longs=literals=others=tokens=0;long_distance=None
  while True:
   symbol=ll.get(r)
   if symbol==256:return longs>=64 and longs*258*10>=produced*9
   tokens+=1
   if tokens>4096:return False
   if symbol<256:
    produced+=1;literals+=1
    if literals>32:return False
    continue
   if symbol==285:length=258;longs+=1
   elif symbol<=264:length=symbol-254;others+=1
   else:
    extra=(symbol-261)//4;length=((4+(symbol-265)%4)<<extra)+3+r.get(extra);others+=1
   if others>8:return False
   d=dist.get(r)
   if d<4:distance=d+1
   else:
    extra=d//2-1;distance=((2+d%2)<<extra)+1+r.get(extra)
   if distance>produced:return False
   if symbol==285:
    if long_distance is not None and distance!=long_distance:return False
    long_distance=distance
   produced+=length
 except Rejected:return False

checks=prefixes=group_checks=0;rows=[];rng=random.Random(471283)
def check(label,data,expected=None):
 global checks
 actual=classify(data);oracle=reference(data);checks+=1
 assert actual==oracle,(label,actual,oracle,data[:40].hex())
 if expected is not None:assert actual==expected,(label,actual,expected)
 rows.append({'name':label,'size':len(data),'accepted':actual})

def group_oracle(hold,bits,pair,width):
 n=0
 while n<bits//width and ((hold>>(n*width))&((1<<width)-1))==pair:n+=1
 return n
for width in range(2,12):
 for pair in range(1<<width):
  tiled=sum(pair<<shift for shift in range(0,32,width))&0xffffffff
  for bits in range(32):
   for hold in [tiled,rng.getrandbits(32)]:
    actual=lib.groups(hold,bits,pair,width);expected=group_oracle(hold,bits,pair,width)
    assert actual==expected,(width,pair,bits,hold,actual,expected);group_checks+=1
 for pair in [0,1,(1<<width)-1,rng.randrange(1<<width)]:
  tiled=sum(pair<<shift for shift in range(0,32,width))&0xffffffff
  for bits in range(32):
   for mismatch in range(32):
    hold=tiled^(1<<mismatch)
    assert lib.groups(hold,bits,pair,width)==group_oracle(hold,bits,pair,width);group_checks+=1
fixtures=json.loads(gzip.decompress((root/'bench/workloads/billy_gzip.json.gz').read_bytes()))
for case in fixtures['cases']:
 if not case['packed']:continue
 packed=base64.b64decode(case['packed']);assert hashlib.sha256(packed).hexdigest()==case['packed_sha256']
 source=io.BytesIO(packed);gzip._read_gzip_header(source);body=source.read()[:131072]
 check('frozen:'+case['name'],body,case['name']=='http-expansion-refusal')
for period in range(1,1025):
 pattern=rng.randbytes(period);raw=(pattern*(65536//period+1))[:65536];body=zlib.compress(raw,wbits=-15)
 check('period:'+str(period),body,period<=16)
 if period<=16:
  for n in range(len(body)):
   assert not classify(body[:n]);prefixes+=1
ns=runpy.run_path(str(root/'tests/suites/product/compress/unit/test_native_adaptive.py'));dynamic=ns['_dynamic']
for name,options,expected in [('literal-only',{'literals':512,'long_matches':0},False),('short-only',{'long_matches':0,'short_matches':512},False),('long63',{'long_matches':63},False),('literal32',{'literals':32},True),('literal33',{'literals':33},False),('other9',{'short_matches':9},False),('density-good',{'short_matches':7,'short_length':257},True),('density-bad',{'short_matches':8,'short_length':257},False),('tokens4096',{'long_matches':4095},True),('tokens4097',{'long_matches':4096},False),('alternating',{'literals':2,'alternating_distances':True},False)]:
 body,raw,_=dynamic(**options);assert zlib.decompress(body,-15)==raw;check(name,body,expected)
 for n in range(len(body)):
  assert not classify(body[:n]);prefixes+=1
for damage in ['empty-precode','oversubscribed-precode','repeat-without-previous','repeat-overflow','missing-end','oversubscribed-literals','incomplete-literals']:
 check('malformed:'+damage,dynamic(malformed=damage)[0],False)
for size in [100,4096,16384,16513,65536,1000000,2000000]:
 body=zlib.compress(b' '*size,wbits=-15);check('spaces:'+str(size),body)
 if size==1000000:
  for n in range(len(body)):
   assert not classify(body[:n]);prefixes+=1
  for _ in range(512):
   changed=bytearray(body);changed[rng.randrange(len(body))]^=1<<rng.randrange(8)
   check('mutated1M',changed)
for n in range(128):
 width=rng.randrange(1,33);raw=bytes(rng.randrange(width) for _ in range(rng.randrange(100,32768)))
 for strategy in [zlib.Z_RLE,zlib.Z_HUFFMAN_ONLY,zlib.Z_DEFAULT_STRATEGY,zlib.Z_FIXED]:
  c=zlib.compressobj(6,zlib.DEFLATED,-15,8,strategy);check(f'random:{n}:{strategy}',c.compress(raw)+c.flush())
for _ in range(10000):
 data=rng.randbytes(rng.randrange(0,512))
 if len(data)>=2 and rng.randrange(2):data=b'\xed'+bytes([data[1]&7])+data[2:]
 check('random-wire',data)
report={'source_sha256':hashlib.sha256((out/'shape.h').read_bytes()).hexdigest(),'group_checks':group_checks,'body_differential_checks':checks,'truncated_body_prefixes':prefixes,'records':rows}
(out/'oracle.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='records'},indent=2))
