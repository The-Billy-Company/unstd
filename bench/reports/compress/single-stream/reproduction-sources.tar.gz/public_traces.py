import ast,gzip,hashlib,importlib.util,io,json,struct,zlib
from pathlib import Path
from unstd.compress import gzipx,_reader,_gzip_native as candidate
root=Path('/Users/griffinstrier/Billy-Company/unstd');out=Path('/tmp/unstd-codec-final-receipts')
basepath=next(Path('/tmp/unstd-single-root/before-qualified/unstd/compress').glob('_gzip_native*.so'));spec=importlib.util.spec_from_file_location('qualified_trace_before._gzip_native',basepath);baseline=importlib.util.module_from_spec(spec);spec.loader.exec_module(baseline)
space={};tree=ast.parse((root/'tests/suites/product/compress/unit/test_native_adaptive.py').read_text())
for node in tree.body:
 if isinstance(node,(ast.ClassDef,ast.FunctionDef)) and node.name in ['_Bits','_dynamic']:exec(compile(ast.Module(body=[node],type_ignores=[]),'<independent-RFC1951-fixtures>','exec'),space)
body,payload,_=space['_dynamic']();wire=b'\x1f\x8b\x08\x00'+bytes(6)+body+struct.pack('<II',zlib.crc32(payload),len(payload));first=gzip.compress(b'first member\n'*30,mtime=0)
cases={'valid':wire,'two-valid':first+wire,'later-crc':first+wire[:-8]+bytes([wire[-8]^1])+wire[-7:],'later-size':first+wire[:-4]+bytes(4),'later-truncated-trailer':first+wire[:-1],'later-junk':first+wire+b'junk','body-damage':wire[:10]+bytes([body[0]^8])+body[1:]+wire[-8:]}
class SourceFault(RuntimeError):pass
class Source(io.BytesIO):
 def __init__(self,data,chunk,fault):super().__init__(data);self.chunk=chunk;self.fault=fault;self.calls=[];self.failure=SourceFault('retained source read failure')
 def read(self,size=-1):
  call=len(self.calls)+1
  if call==self.fault:self.calls.append((size,'fault'));raise self.failure
  result=super().read(min(size,self.chunk) if size>=0 else self.chunk);self.calls.append((size,len(result)));return result

def history(module,data,method,size,chunk,fault):
 _reader._factory=module.Inflater;source=Source(data,chunk,fault);parts=[];buffer=bytearray([0xA5])*size;error=None;identity=None
 try:
  with gzipx.GzipFile(fileobj=source) as reader:
   for _ in range(10000):
    if method=='readinto':
     count=reader.readinto(buffer)
     if not count:break
     parts.append(bytes(buffer[:count]))
    else:
     value=getattr(reader,method)(size)
     if not value:break
     parts.append(value)
   else:raise AssertionError('bounded trace did not terminate')
 except (OSError,EOFError,zlib.error,SourceFault) as exc:error=(type(exc).__name__,exc.args);identity=exc is source.failure if isinstance(exc,SourceFault) else None
 return {'delivered':b''.join(parts),'error':error,'source_fault_identity':identity,'calls':source.calls,'source_position':source.tell(),'source_still_open':not source.closed,'buffer':bytes(buffer)}
rows=[];original=_reader._factory
try:
 for name,data in cases.items():
  for method,size in [('read',31),('read',8192),('read1',31),('read1',32768),('readinto',31),('readinto',8192)]:
   for chunk in [len(data)+1,73]:
    for fault in [0,4]:
     left=history(baseline,data,method,size,chunk,fault);right=history(candidate,data,method,size,chunk,fault)
     assert left==right,(name,method,size,chunk,fault,left,right)
     rows.append({'case':name,'method':method,'size':size,'chunk':chunk,'fault_read':fault,'delivered_bytes':len(right['delivered']),'delivered_sha256':hashlib.sha256(right['delivered']).hexdigest(),'error':right['error'],'source_reads':len(right['calls']),'source_position':right['source_position'],'source_still_open':right['source_still_open'],'source_fault_identity':right['source_fault_identity'],'failed_buffer_sha256':hashlib.sha256(right['buffer']).hexdigest()})
finally:_reader._factory=original
report={'candidate':candidate.__file__,'baseline':str(basepath),'ng_version':candidate._ng_runtime_version(),'traces':len(rows),'exact_history_equality':True,'fields_compared':['delivered bytes','error class and args','source failure object identity','exact source read calls','source position','borrowed source remains open','readinto buffer contents after failures'],'results':rows}
(out/'public-traces-final16.json').write_text(json.dumps(report,indent=2)+'\n');print(len(rows),'public fault/budget/ownership/readinto histories match exact prior-final Apple implementation')
