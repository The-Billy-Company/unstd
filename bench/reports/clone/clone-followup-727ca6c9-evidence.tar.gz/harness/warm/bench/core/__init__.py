"""Core benchmark tooling."""
