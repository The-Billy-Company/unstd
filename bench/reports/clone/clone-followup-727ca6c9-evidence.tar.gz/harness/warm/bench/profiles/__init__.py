"""Profiles benchmark tooling."""
