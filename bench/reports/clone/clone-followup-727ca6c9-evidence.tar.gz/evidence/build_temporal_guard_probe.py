from pathlib import Path
import difflib
import json
import shutil
import subprocess
import sysconfig


root = Path(__file__).resolve().parents[2]
folder = Path(__file__).resolve().parent
control = folder / "temporal-guard-control"
candidate = folder / "temporal-guard-candidate"
for target in (control, candidate):
    target.mkdir(exist_ok=True)
    shutil.copy2(root / "src/unstd/clone/structural.py", target / "structural.py")
    shutil.copy2(folder / "final-documented/manifest.json", target / "manifest.json")
for name in ("adapter.c", "_clone_native" + sysconfig.get_config_var("EXT_SUFFIX")):
    shutil.copy2(folder / "final-documented" / name, control / name)
source = (control / "adapter.c").read_text()


def replace(old: str, new: str, count: int = 1) -> None:
    global source
    assert source.count(old) == count, (old[:100], source.count(old), count)
    source = source.replace(old, new)


replace("#include <stdint.h>", "#include <stdint.h>\n#include <stddef.h>")
replace(
    "static int\nordinary_namespace(PyObject *dictionary)",
    """/* CPython 3.12--3.14 share this dictionary-key prefix. Reading its kind
 * byte is the same O(1) proof used by _PyDict_HasOnlyStringKeys; that function
 * is hidden in 3.13/3.14. Unicode/split tables contain exact str keys. General
 * tables still need the exact-str scan, since str subclasses may run hooks. */
typedef struct {
    Py_ssize_t references;
    uint8_t log_size;
    uint8_t log_index_bytes;
    uint8_t kind;
} DictKeysPrefix;

static int
ordinary_namespace(PyObject *dictionary)""",
)
replace(
    "    Py_ssize_t position = 0;\n    PyObject *key, *value;\n    while (PyDict_Next(dictionary, &position, &key, &value)) {",
    """#if PY_VERSION_HEX >= 0x030C0000 && PY_VERSION_HEX < 0x030F0000 && !defined(Py_GIL_DISABLED)
    const unsigned char *keys = (const unsigned char *)((PyDictObject *)dictionary)->ma_keys;
    unsigned char kind = keys[offsetof(DictKeysPrefix, kind)];
    if (kind == 1 || kind == 2) {
        return 1;
    }
#endif
    Py_ssize_t position = 0;
    PyObject *key, *value;
    while (PyDict_Next(dictionary, &position, &key, &value)) {""",
)

begin = source.index("/* The temporal branch follows two type memberships")
end = source.index("/* Only a complete root sequence", begin)
source = source[:begin] + r'''
/* A bounded, callback-free proof of CPython set_lookkey's actual probe chain
 * (Objects/setobject.c, 3.12--3.14). Only matching hashes can compare keys.
 * Foreign comparisons defer before running them; exact type keys compare by
 * identity. No policy references escape this allocation-free check, so policy
 * replacement retains its ordinary weakref/finalizer timing. */
static int
exact_type_membership(PyObject *set, PyTypeObject *kind, Py_ssize_t limit,
                      Py_ssize_t mask_limit)
{
    if (set == NULL || !PyFrozenSet_CheckExact(set) || PySet_GET_SIZE(set) > limit) {
        return -1;
    }
    PySetObject *policy = (PySetObject *)set;
    if (policy->mask >= mask_limit) {
        return -1;
    }
    Py_hash_t hash = PyObject_Hash((PyObject *)kind);
    if (hash == -1) {
        return -1;
    }
    size_t mask = (size_t)policy->mask;
    size_t perturb = (size_t)hash, index = (size_t)hash & mask;
    size_t budget = (mask + 1) * 4;
    while (budget != 0) {
        size_t end = index + 9 <= mask ? index + 9 : index;
        for (size_t i = index; i <= end && budget != 0; i++, budget--) {
            setentry entry = policy->table[i];
            if (entry.hash == 0 && entry.key == NULL) {
                return 0;
            }
            if (entry.hash == hash) {
                if (entry.key == (PyObject *)kind) {
                    return 1;
                }
                if (Py_TYPE(entry.key) != &PyType_Type) {
                    return -1;
                }
            }
        }
        perturb >>= 5;
        index = (index * 5 + 1 + perturb) & mask;
    }
    return -1;
}

static int
temporal_memberships_safe(ModuleState *state, PyObject *globals, PyTypeObject *kind)
{
    if (!ordinary_namespace(globals)) {
        return 0;
    }
    PyObject *atoms = PyDict_GetItemWithError(globals, PyTuple_GET_ITEM(state->closed_names, 0));
    PyObject *graph = PyDict_GetItemWithError(globals, PyTuple_GET_ITEM(state->closed_names, 3));
    return exact_type_membership(atoms, kind, 64, 128) == 0
        && exact_type_membership(graph, kind, 64, 128) == 0
        && exact_type_membership(graph, Py_TYPE(state->datetime_api->TimeZone_UTC), 64, 128) == 0
        && exact_type_membership(graph, Py_TYPE(Py_None), 64, 128) == 1;
}

''' + source[end:]

begin = source.index("    if (!PyFrozenSet_CheckExact(zones) || PySet_GET_SIZE(zones) > 8) {", source.index("temporal_value("))
end = source.index("    PyObject *identity = PyLong_FromVoidPtr(source);", begin)
source = source[:begin] + """    if (exact_type_membership(zones, Py_TYPE(zone), 8, 32) != 1) {
        return 0;
    }
""" + source[end:]

replace(
    "        if (!atom(item) && kind != api->DateType && kind != api->DateTimeType\n            && kind != api->TimeType) {",
    "        if (kind != api->DateType && kind != api->DateTimeType\n            && kind != api->TimeType && !atom(item)) {",
)
replace(
    "    if (Py_SIZE(source) != size || Py_GetRecursionLimit() != recursion_limit) {",
    "    if (flags == 0 || Py_SIZE(source) != size || Py_GetRecursionLimit() != recursion_limit) {",
)
replace(
    "        if (!atom(item) && !closed_temporal_atom(item, flags, api)) {\n            Py_DECREF(output);\n            return 0;\n        }\n    }\n    for (Py_ssize_t i = 0; i < size; i++) {\n        PyObject *item = tuple ? PyTuple_GET_ITEM(source, i) : PyList_GET_ITEM(source, i);",
    "        if (!closed_temporal_atom(item, flags, api) && !atom(item)) {\n            Py_DECREF(output);\n            return 0;\n        }",
)
replace(
    " * its copy protocol. Validate all leaves after the sole output allocation and\n * before filling any slot. No allocation/callback follows that validation.",
    " * its copy protocol. After the sole output allocation, validate each leaf\n * before filling its slot. No allocation/callback occurs in this bounded loop;\n * source retains every approved immutable prefix leaf if later refusal must\n * discard the private output before the ordinary continuation starts.",
)
(candidate / "adapter.c").write_text(source)
command = ["clang", "-O3", "-fPIC", "-std=c11", "-shared", "-undefined", "dynamic_lookup", "-Wall", "-Wextra", "-Werror", "-I" + sysconfig.get_paths()["include"], str(candidate / "adapter.c"), "-o", str(candidate / ("_clone_native" + sysconfig.get_config_var("EXT_SUFFIX")))]
subprocess.run(command, check=True)
(candidate / "build-command.json").write_text(json.dumps(command, indent=2) + "\n")
(folder / "temporal-guard-owned.patch").write_text("".join(difflib.unified_diff((control / "adapter.c").read_text().splitlines(True),source.splitlines(True),fromfile="a/native/clone/src/adapter.c",tofile="b/native/clone/src/adapter.c")))
print("Private temporal guards/root-loop candidate compiled; production untouched")
