from pathlib import Path
import difflib
import shutil
import subprocess
import sysconfig


folder = Path(__file__).resolve().parent
control = folder / "temporal-guard-control"
candidate = folder / "temporal-final-candidate"
candidate.mkdir(exist_ok=True)
for name in ("structural.py", "manifest.json"):
    shutil.copy2(folder / "temporal-parent-candidate" / name, candidate / name)
source = (folder / "temporal-parent-candidate/adapter.c").read_text()


def replace(old: str, new: str, count: int = 1) -> None:
    global source
    assert source.count(old) == count, (old[:100], source.count(old), count)
    source = source.replace(old, new)


replace("    int canonical_graph;\n", "    int canonical_graph;\n    PyObject *loop_walk_code;\n")
begin = source.index("static int\nclone_loop_value(")
end = source.index("/* Copy a first repeated non-atomic run", begin)
source = source[:begin] + r'''
/* Inspect certificates without adding foreign namespace-key comparisons.
 * Actual parent identifiers are still resolved through the ordinary dict API. */
static PyObject *
loop_certificate(PyObject *globals, PyObject *name, int ordinary)
{
    if (ordinary) {
        return PyDict_GetItemWithError(globals, name);
    }
    Py_ssize_t position = 0;
    PyObject *key, *value;
    while (PyDict_Next(globals, &position, &key, &value)) {
        if (PyUnicode_CheckExact(key)
            && (key == name || PyUnicode_Compare(key, name) == 0)) {
            return value;
        }
    }
    return NULL;
}

static int
clone_loop_value(PyObject *source, PyObject **result, unsigned int depth,
                 CopyContext *context)
{
    if (context->canonical_graph && PyFunction_Check(context->walk)) {
        PyDateTime_CAPI *api = context->module_state->datetime_api;
        PyTypeObject *kind = Py_TYPE(source);
        if (kind == api->DateTimeType || kind == api->TimeType || kind == api->DateType) {
            PyObject *globals = PyFunction_GetGlobals(context->walk);
            PyObject *names = context->module_state->temporal_names;
            PyObject *graph_name = PyTuple_GET_ITEM(context->module_state->closed_names, 3);
            PyObject *policy = NULL;
            if (!context->temporal_loop_dynamic) {
                int ordinary = ordinary_namespace(globals);
                int membership = -1;
                int changed_walk = 1;
                if (ordinary) {
                    policy = PyDict_GetItemWithError(globals, graph_name);
                    membership = exact_type_membership(policy, kind, 64, 128);
                    changed_walk = PyDict_GetItemWithError(globals,
                        PyTuple_GET_ITEM(names, 9)) != context->walk
                        || PyFunction_GetCode(context->walk) != context->loop_walk_code;
                }
                if (membership == 0 && !changed_walk) {
                    return clone_value(source, result, depth, context);
                }
                /* Retain the entry code as Python's active parent frame does:
                 * a preceding hook may change the function's current code. */
                if (loop_certificate(globals, PyTuple_GET_ITEM(names, 0), ordinary)
                        != context->walk
                    || loop_certificate(globals, PyTuple_GET_ITEM(names, 1), ordinary)
                        != context->loop_walk_code) {
                    return clone_value(source, result, depth, context);
                }
                if (membership == 1) {
                    *result = Py_NewRef(source);
                    return 1;
                }
            }
            if (policy == NULL) {
                /* These are actual parent lookups; preserve their exceptions,
                 * including foreign-key equality after earlier callbacks. */
                policy = PyDict_GetItemWithError(globals, graph_name);
            }
            if (policy == NULL) {
                if (!PyErr_Occurred()) {
                    PyErr_SetString(PyExc_NameError, "name '_GRAPH_ATOMS' is not defined");
                }
                return -1;
            }
            context->temporal_graph = 0;
            context->temporal_loop_dynamic = 1;
            Py_INCREF(policy);
            int contains = PySequence_Contains(policy, (PyObject *)kind);
            Py_DECREF(policy);
            if (contains < 0) {
                return -1;
            }
            if (contains) {
                *result = Py_NewRef(source);
                return 1;
            }
            PyObject *walk = PyDict_GetItemWithError(globals, PyTuple_GET_ITEM(names, 9));
            if (walk == NULL) {
                if (!PyErr_Occurred()) {
                    PyErr_SetString(PyExc_NameError, "name '_walk' is not defined");
                }
                return -1;
            }
            Py_INCREF(walk);
            *result = PyObject_CallFunctionObjArgs(walk, source, context->memo, NULL);
            Py_DECREF(walk);
            return *result == NULL ? -1 : 1;
        }
    }
    return clone_value(source, result, depth, context);
}

''' + source[end:]

begin = source.index("static PyObject *\nclone_direct_graph(")
end = source.index("static PyObject *\nclone_record_graph(", begin)
function = source[begin:end]
old = "    ModuleState *state = PyModule_GetState(module);\n"
assert function.count(old) == 1
function = function.replace(old, old + "    PyObject *entry_walk_code = temporal && PyFunction_Check(walk)\n        ? Py_NewRef(PyFunction_GetCode(walk)) : NULL;\n")
old = "        Py_DECREF(update_name);\n"
assert function.count(old) == 3
function = function.replace(old, old + "        Py_XDECREF(entry_walk_code);\n")
old = "    context.canonical_graph = temporal;\n"
assert function.count(old) == 1
function = function.replace(old, old + "    context.loop_walk_code = entry_walk_code;\n")
old = "    return status == 1 ? result : NULL;\n"
assert function.count(old) == 1
function = function.replace(old, "    Py_XDECREF(entry_walk_code);\n" + old)
source = source[:begin] + function + source[end:]
(candidate / "adapter.c").write_text(source)
(folder / "temporal-final-owned.patch").write_text("".join(difflib.unified_diff((control / "adapter.c").read_text().splitlines(True),source.splitlines(True),fromfile="a/native/clone/src/adapter.c",tofile="b/native/clone/src/adapter.c")))
if "--compile" in __import__("sys").argv:
    subprocess.run(["clang", "-O3", "-fPIC", "-std=c11", "-shared", "-undefined", "dynamic_lookup", "-Wall", "-Wextra", "-Werror", "-I" + sysconfig.get_paths()["include"], str(candidate / "adapter.c"), "-o", str(candidate / ("_clone_native" + sysconfig.get_config_var("EXT_SUFFIX")))], check=True)
    print("Private final temporal continuation compiled; production untouched")
else:
    print("Private final temporal source/patch prepared without compiler/test CPU")
