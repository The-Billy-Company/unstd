from __future__ import annotations

import datetime as dt
import importlib.util
from pathlib import Path
import sysconfig

from hypothesis import given, settings, strategies as st
import pytest


FOLDER = Path(__file__).resolve().parent / "temporal-guard-candidate"
spec = importlib.util.spec_from_file_location("_clone_policy_probe", FOLDER / ("_clone_policy_probe" + sysconfig.get_config_var("EXT_SUFFIX")))
diagnostic = importlib.util.module_from_spec(spec)
spec.loader.exec_module(diagnostic)


@settings(max_examples=500, deadline=None)
@given(
    chosen=st.sampled_from([dt.datetime, dt.time, dt.date, type(None), dt.timezone]),
    hashes=st.lists(st.integers(-12, 12), max_size=20),
    include=st.booleans(),
    first=st.booleans(),
    mode=st.sampled_from(["false", "true", "error"]),
    remove=st.integers(0, 12),
)
def test_exact_probe_matches_real_contains_without_invoking_foreign_keys(chosen, hashes, include, first, mode, remove):
    calls = []
    armed = False
    failure = LookupError("real membership comparison")
    keys = []
    for index, offset in enumerate(hashes):
        def hash_key(cls, offset=offset):
            return hash(chosen) + offset

        def compare_key(cls, other, index=index):
            if armed:
                calls.append((index, other))
                if mode == "error":
                    raise failure
                return mode == "true"
            return False

        meta = type("ForeignMeta", (type,), {"__hash__": hash_key, "__eq__": compare_key})
        keys.append(meta("ForeignKey", (), {}))
    if include:
        keys.insert(0 if first else len(keys), chosen)
    # The diagnostic constructor preserves legal dummy table positions from
    # discarded keys, then exposes the shared set/frozenset table as frozen.
    discarded = keys[:min(remove, len(keys))]
    policy = diagnostic.frozen_dummies(keys, discarded)
    armed = True
    actual = diagnostic.probe(policy, chosen)
    assert actual in (-1, 0, 1)
    assert calls == []
    try:
        expected = chosen in policy
    except LookupError as observed:
        assert observed is failure
        assert actual == -1
    else:
        if actual >= 0:
            assert bool(actual) is expected
            assert calls == []
        elif len(policy) <= 64:
            # An unprovable on-path comparison remains entirely Python-owned.
            assert calls


def test_namespace_unicode_fast_proof_preserves_str_subclass_boundary():
    calls = []

    class ForeignString(str):
        def __hash__(self):
            calls.append("hash")
            return str.__hash__(self)

        def __eq__(self, other):
            calls.append("eq")
            return str.__eq__(self, other)

    class Record:
        pass

    record = Record()
    record.first = 1
    cases = [
        ({"first": 1, "second": 2}, True),
        ({ForeignString("foreign"): 1}, False),
        ({"first": 1, ForeignString("foreign"): 2}, False),
        (record.__dict__, True),
    ]
    formerly_mixed = {"first": 1, ForeignString("foreign"): 2}
    del formerly_mixed["foreign"]
    cases.append((formerly_mixed, True))
    for namespace, expected in cases:
        calls.clear()
        assert diagnostic.namespace(namespace) is expected
        assert calls == []


@pytest.mark.parametrize("chosen", [dt.datetime, dt.time, type(None), dt.timezone])
def test_static_type_probe_does_not_hash_foreign_metaclasses(chosen):
    calls = []

    class Meta(type):
        def __hash__(cls):
            calls.append("hash")
            return hash(chosen) + 1

        def __eq__(cls, other):
            calls.append("eq")
            raise AssertionError

    class Foreign(metaclass=Meta):
        pass

    policy = frozenset({Foreign})
    calls.clear()
    assert diagnostic.probe(policy, chosen) == 0
    assert calls == []
    assert chosen not in policy
    assert calls == []
