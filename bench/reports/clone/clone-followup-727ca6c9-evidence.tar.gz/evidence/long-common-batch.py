"""Use the unchanged public clone timing loop with longer calibrated batches."""
from bench.profiles import clone_cpu as base
from bench.profiles import clone_common_cpu as common

base.BATCH_TARGET_NS = 200_000_000
common.main()
