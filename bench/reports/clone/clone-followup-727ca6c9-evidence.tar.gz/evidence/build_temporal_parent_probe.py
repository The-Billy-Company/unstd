from pathlib import Path
import difflib
import shutil
import subprocess
import sysconfig


folder = Path(__file__).resolve().parent
control = folder / "temporal-guard-control"
candidate = folder / "temporal-parent-candidate"
candidate.mkdir(exist_ok=True)
for name in ("structural.py", "manifest.json"):
    shutil.copy2(folder / "temporal-guard-candidate" / name, candidate / name)
source = (folder / "temporal-guard-candidate/adapter.c").read_text()


def replace(old: str, new: str, count: int = 1) -> None:
    global source
    assert source.count(old) == count, (old[:100], source.count(old), count)
    source = source.replace(old, new)


replace("    int direct_graph;\n", "    int direct_graph;\n    int canonical_graph;\n    int temporal_loop_dynamic;\n")
replace("    context.direct_graph = 1;\n", "    context.direct_graph = 1;\n    context.canonical_graph = temporal;\n    context.temporal_loop_dynamic = 0;\n")
helper = r'''
/* Python container loops test graph-atom membership before calling _walk.
 * A foreign temporal policy must retain BOTH that parent test and the leaf's
 * own test, even on a repeated leaf already present in the shared memo. */
static int
clone_loop_value(PyObject *source, PyObject **result, unsigned int depth,
                 CopyContext *context)
{
    if (context->canonical_graph && PyFunction_Check(context->walk)) {
        PyDateTime_CAPI *api = context->module_state->datetime_api;
        PyTypeObject *kind = Py_TYPE(source);
        if (kind == api->DateTimeType || kind == api->TimeType || kind == api->DateType) {
            PyObject *globals = PyFunction_GetGlobals(context->walk);
            PyObject *names = context->module_state->temporal_names;
            PyObject *policy;
            if (!context->temporal_loop_dynamic) {
                if (!ordinary_namespace(globals)) {
                    return clone_value(source, result, depth, context);
                }
                policy = PyDict_GetItemWithError(globals,
                    PyTuple_GET_ITEM(context->module_state->closed_names, 3));
                int membership = exact_type_membership(policy, kind, 64, 128);
                if (membership == 0
                    || PyDict_GetItemWithError(globals, PyTuple_GET_ITEM(names, 0)) != context->walk
                    || PyDict_GetItemWithError(globals, PyTuple_GET_ITEM(names, 1))
                        != PyFunction_GetCode(context->walk)) {
                    return clone_value(source, result, depth, context);
                }
                if (membership == 1) {
                        *result = Py_NewRef(source);
                        return 1;
                }
            } else {
                /* After a callback, these are the parent's actual identifier
                 * lookups, including any newly foreign namespace keys. */
                policy = PyDict_GetItemWithError(globals,
                    PyTuple_GET_ITEM(context->module_state->closed_names, 3));
            }
                    if (policy == NULL) {
                        PyErr_SetString(PyExc_NameError, "name '_GRAPH_ATOMS' is not defined");
                        return -1;
                    }
                    /* Arbitrary membership callbacks can change dispatch or
                     * the memo. Keep subsequent temporal loop tests in Python's
                     * live order instead of reviving a cached native decision. */
                    context->temporal_graph = 0;
                    context->temporal_loop_dynamic = 1;
                    Py_INCREF(policy);
                    int contains = PySequence_Contains(policy, (PyObject *)kind);
                    Py_DECREF(policy);
                    if (contains < 0) {
                        return -1;
                    }
                    if (contains) {
                        *result = Py_NewRef(source);
                        return 1;
                    }
                    PyObject *walk = PyDict_GetItemWithError(globals,
                        PyTuple_GET_ITEM(names, 9));
                    if (walk == NULL) {
                        if (!PyErr_Occurred()) {
                            PyErr_SetString(PyExc_NameError, "name '_walk' is not defined");
                        }
                        return -1;
                    }
                    Py_INCREF(walk);
                    *result = PyObject_CallFunctionObjArgs(walk, source, context->memo, NULL);
                    Py_DECREF(walk);
                    return *result == NULL ? -1 : 1;
        }
    }
    return clone_value(source, result, depth, context);
}

'''
replace("/* Copy a first repeated non-atomic run into private reserved slots. */", helper + "/* Copy a first repeated non-atomic run into private reserved slots. */")
replace("? clone_value(item, &copied, depth - 1, context)", "? clone_loop_value(item, &copied, depth - 1, context)")
replace("? clone_value(key, &copied_key, depth - 1, context)", "? clone_loop_value(key, &copied_key, depth - 1, context)")
replace("? clone_value(value, &copied, depth - 1, context)", "? clone_loop_value(value, &copied, depth - 1, context)")
replace("status = clone_value(item, &copied, depth - 1, context);", "status = clone_loop_value(item, &copied, depth - 1, context);")
replace(
    "/* A bounded, callback-free proof of CPython set_lookkey's actual probe chain\n * (Objects/setobject.c, 3.12--3.14). Only matching hashes can compare keys.",
    "/* Independent bounded proof of the standard CPython probe geometry:\n * https://github.com/python/cpython/blob/3.12/Objects/setobject.c#L49\n * https://github.com/python/cpython/blob/3.14/Objects/setobject.c#L70\n * Qualified GIL builds use the default nine-step linear window and perturb5.\n * Only matching hashes can compare keys.",
)
begin = source.index("static int\nexact_type_membership(")
end = source.index("static int\ntemporal_memberships_safe(", begin)
probe = source[begin:end]
probe = probe.replace(
    "{\n    if (set == NULL",
    "{\n#if PY_VERSION_HEX < 0x030C0000 || PY_VERSION_HEX >= 0x030F0000 || defined(Py_GIL_DISABLED) \\\n    || (defined(LINEAR_PROBES) && LINEAR_PROBES != 9)\n    (void)set; (void)kind; (void)limit; (void)mask_limit;\n    return -1;\n#else\n    if (set == NULL",
)
assert probe.endswith("    return -1;\n}\n\n")
probe = probe.removesuffix("    return -1;\n}\n\n") + "    return -1;\n#endif\n}\n\n"
source = source[:begin] + probe + source[end:]
(candidate / "adapter.c").write_text(source)
subprocess.run(["clang", "-O3", "-fPIC", "-std=c11", "-shared", "-undefined", "dynamic_lookup", "-Wall", "-Wextra", "-Werror", "-I" + sysconfig.get_paths()["include"], str(candidate / "adapter.c"), "-o", str(candidate / ("_clone_native" + sysconfig.get_config_var("EXT_SUFFIX")))], check=True)
(folder / "temporal-guard-parent-owned.patch").write_text("".join(difflib.unified_diff((control / "adapter.c").read_text().splitlines(True),source.splitlines(True),fromfile="a/native/clone/src/adapter.c",tofile="b/native/clone/src/adapter.c")))
print("Private temporal parent continuation built; production untouched")
