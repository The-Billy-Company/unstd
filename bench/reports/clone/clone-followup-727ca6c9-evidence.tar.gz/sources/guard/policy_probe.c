#include <Python.h>
#include <stdint.h>
#include <stddef.h>
typedef struct {
    Py_ssize_t references;
    uint8_t log_size;
    uint8_t log_index_bytes;
    uint8_t kind;
} DictKeysPrefix;

static int
ordinary_namespace(PyObject *dictionary)
{
    if (dictionary == NULL || !PyDict_CheckExact(dictionary)
        || PyDict_GET_SIZE(dictionary) > 4096) {
        return 0;
    }
#if PY_VERSION_HEX >= 0x030C0000 && PY_VERSION_HEX < 0x030F0000 && !defined(Py_GIL_DISABLED)
    const unsigned char *keys = (const unsigned char *)((PyDictObject *)dictionary)->ma_keys;
    unsigned char kind = keys[offsetof(DictKeysPrefix, kind)];
    if (kind == 1 || kind == 2) {
        return 1;
    }
#endif
    Py_ssize_t position = 0;
    PyObject *key, *value;
    while (PyDict_Next(dictionary, &position, &key, &value)) {
        if (!PyUnicode_CheckExact(key)) {
            return 0;
        }
    }
    return 1;
}

static int
exact_type_membership(PyObject *set, PyTypeObject *kind, Py_ssize_t limit,
                      Py_ssize_t mask_limit)
{
    if (set == NULL || !PyFrozenSet_CheckExact(set) || PySet_GET_SIZE(set) > limit) {
        return -1;
    }
    PySetObject *policy = (PySetObject *)set;
    if (policy->mask >= mask_limit) {
        return -1;
    }
    Py_hash_t hash = PyObject_Hash((PyObject *)kind);
    if (hash == -1) {
        return -1;
    }
    size_t mask = (size_t)policy->mask;
    size_t perturb = (size_t)hash, index = (size_t)hash & mask;
    size_t budget = (mask + 1) * 4;
    while (budget != 0) {
        size_t end = index + 9 <= mask ? index + 9 : index;
        for (size_t i = index; i <= end && budget != 0; i++, budget--) {
            setentry entry = policy->table[i];
            if (entry.hash == 0 && entry.key == NULL) {
                return 0;
            }
            if (entry.hash == hash) {
                if (entry.key == (PyObject *)kind) {
                    return 1;
                }
                if (Py_TYPE(entry.key) != &PyType_Type) {
                    return -1;
                }
            }
        }
        perturb >>= 5;
        index = (index * 5 + 1 + perturb) & mask;
    }
    return -1;
}


static PyObject *check_membership(PyObject *module, PyObject *args) {
 (void)module; PyObject *set,*kind;
 if (!PyArg_ParseTuple(args,"OO",&set,&kind)) return NULL;
 if (!PyType_Check(kind) || Py_TYPE(kind)!=&PyType_Type) {PyErr_SetString(PyExc_TypeError,"ordinary type required");return NULL;}
 return PyLong_FromLong(exact_type_membership(set,(PyTypeObject*)kind,64,128));
}
static PyObject *check_namespace(PyObject *module,PyObject *dictionary) {
 (void)module;return PyBool_FromLong(ordinary_namespace(dictionary));
}
/* Validation-only fixture: identical set/frozenset layouts retain legal dummy
 * entries after deletion. Never expose this constructor in the product ABI. */
static PyObject *frozen_dummies(PyObject *module,PyObject *args) {
 (void)module;PyObject *items,*removals;
 if(!PyArg_ParseTuple(args,"OO",&items,&removals))return NULL;
 PyObject *set=PySet_New(items);if(set==NULL)return NULL;
 PyObject *it=PyObject_GetIter(removals);if(it==NULL){Py_DECREF(set);return NULL;}
 PyObject *item;while((item=PyIter_Next(it))!=NULL){int ok=PySet_Discard(set,item);Py_DECREF(item);if(ok<0){Py_DECREF(it);Py_DECREF(set);return NULL;}}
 Py_DECREF(it);if(PyErr_Occurred()){Py_DECREF(set);return NULL;}
 Py_SET_TYPE(set,&PyFrozenSet_Type);return set;
}
static PyMethodDef methods[]={{"probe",check_membership,METH_VARARGS,NULL},{"namespace",check_namespace,METH_O,NULL},{"frozen_dummies",frozen_dummies,METH_VARARGS,NULL},{NULL,NULL,0,NULL}};
static struct PyModuleDef module={PyModuleDef_HEAD_INIT,"_clone_policy_probe",NULL,-1,methods,NULL,NULL,NULL,NULL};
PyMODINIT_FUNC PyInit__clone_policy_probe(void){return PyModule_Create(&module);}
