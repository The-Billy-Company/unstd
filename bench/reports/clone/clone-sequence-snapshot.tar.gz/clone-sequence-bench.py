import json
import os
from pathlib import Path
import subprocess
import sys

if len(sys.argv) > 1 and sys.argv[1] == "worker":
    from bench.profiles import clone_common_cpu as profile
    profile.main(sys.argv[2:])
else:
    results = {}
    for version in sys.argv[1:]:
        for gc in (False, True):
            suffix = "-gc" if gc else ""
            target = Path(f"/work/clone-sequence-foundry-py{version}{suffix}.json")
            interpreter = "/work/venv/bin/python" if version == "314" else "/work/venv313/bin/python"
            env = os.environ.copy()
            env["PYTHONPATH"] = "/work/source"
            command = [interpreter, "/work/clone-sequence-bench.py", "worker", "--compare-dir", "/work/before-current", "--original-dir", "/work/before/src/unstd/clone", "--infer-native-bindings", "--require-native", "--rounds", "15", "--max-slowdown", "1.10", "--output", str(target)]
            if gc:
                command.append("--gc-enabled")
            with Path(f"/work/benchmark-{version}{suffix}.log").open("w") as stream:
                code = subprocess.run(command, env=env, stdout=stream, stderr=subprocess.STDOUT).returncode
            results[target.name] = code
            print(target.name, code, flush=True)
    Path("/work/benchmark-results-" + "-".join(sys.argv[1:]) + ".json").write_text(json.dumps(results))
    raise SystemExit(int(any(results.values())))
