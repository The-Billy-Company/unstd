#include <stdlib.h>
void unstd_asan_positive_control(void) {
    volatile int *values = malloc(sizeof(int));
    values[1] = 42;
    free((void *)values);
}
