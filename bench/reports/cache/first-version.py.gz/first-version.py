"""Persistent JSON results, with transactional fills shared across processes.

``Cache`` composes :mod:`unstd.serde.jsonx` with stdlib SQLite. Each operation
owns and closes its connection, so a handle can be shared by threads or reused
after a fork. See the package guide for expiry, eviction and writer contention.
"""

from __future__ import annotations

from contextlib import closing
import math
import os
from pathlib import Path
import sqlite3
import time
from typing import TYPE_CHECKING, Any, cast

from unstd import fs
from unstd.serde import jsonx


if TYPE_CHECKING:
    from collections.abc import Callable
    from os import PathLike

    from unstd.serde.jsonx import Json


__all__ = ["Cache"]

_MISSING = object()


def _seconds(value: float, name: str) -> float:
    """A finite, nonnegative duration, rejecting booleans and strings."""
    if isinstance(value, bool) or not isinstance(value, int | float):
        msg = f"{name} must be a finite nonnegative number"
        raise TypeError(msg)
    try:
        result = float(value)
    except OverflowError as error:
        msg = f"{name} must be finite and nonnegative"
        raise ValueError(msg) from error
    if not math.isfinite(result) or result < 0:
        msg = f"{name} must be finite and nonnegative"
        raise ValueError(msg)
    return result


def _text(value: str, name: str) -> None:
    """SQLite names and keys are UTF-8 strings, never SQL fragments."""
    if not isinstance(value, str):
        msg = f"{name} must be a string"
        raise TypeError(msg)
    value.encode("utf-8")


def _encode(value: Json) -> bytes:
    """Portable JSON with finite numbers and escaped lone surrogates."""
    return jsonx.dumps(
        value, allow_nan=False, ensure_ascii=True, separators=(",", ":")
    ).encode("utf-8")


class Cache:
    """A namespaced, disk-backed JSON cache with optional TTL and FIFO capacity.

    The parent directory is created as needed. New database files request mode
    ``0o600``; existing permissions are retained. Use a trusted local directory
    on a filesystem supporting SQLite WAL. Connections use full synchronization.
    ``timeout`` bounds SQLite lock waits, not the duration of a producer.
    """

    def __init__(
        self,
        path: str | PathLike[str],
        *,
        namespace: str = "default",
        timeout: float = 30.0,
        max_entries: int | None = None,
    ) -> None:
        """Initialize a persistent cache without retaining a connection."""
        _text(namespace, "namespace")
        self._timeout = _seconds(timeout, "timeout")
        if max_entries is not None and (
            type(max_entries) is not int or max_entries <= 0
        ):
            msg = "max_entries must be a positive integer or None"
            raise ValueError(msg)
        self._path = Path(path).absolute()
        self._namespace = namespace
        # SQLite's OFFSET accepts a signed 64-bit integer; larger capacities
        # are indistinguishable because SQLite cannot store that many rows.
        self._max_entries = (
            None if max_entries is None else min(max_entries, (1 << 63) - 1)
        )
        fs.ensure_dir(self._path.parent)
        try:
            descriptor = os.open(
                self._path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600
            )
        except FileExistsError:
            pass
        else:
            os.close(descriptor)
        with closing(self._connect()) as connection:
            # Reopening a populated cache must not contend with a slow fill.
            # Schema creation below is atomic, so a visible table is complete.
            exists = connection.execute(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' "
                "AND name = '_unstd_cache_v1'"
            ).fetchone()
            mode = connection.execute("PRAGMA journal_mode").fetchone()
            if exists is not None and mode == ("wal",):
                return
            mode = connection.execute("PRAGMA journal_mode = WAL").fetchone()
            if mode != ("wal",):
                msg = "cache requires SQLite WAL journal mode"
                raise sqlite3.OperationalError(msg)
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                connection.execute(
                    "CREATE TABLE IF NOT EXISTS _unstd_cache_v1 ("
                    "namespace TEXT NOT NULL, key TEXT NOT NULL, value BLOB NOT NULL, "
                    "expires_at REAL, written_at INTEGER NOT NULL, "
                    "PRIMARY KEY (namespace, key))"
                )
                connection.execute(
                    "CREATE INDEX IF NOT EXISTS _unstd_cache_v1_expiry "
                    "ON _unstd_cache_v1 (namespace, expires_at)"
                )
                connection.execute(
                    "CREATE INDEX IF NOT EXISTS _unstd_cache_v1_order "
                    "ON _unstd_cache_v1 (namespace, written_at)"
                )

    def _connect(self) -> sqlite3.Connection:
        """An autocommit connection whose owner must close it."""
        connection = sqlite3.connect(
            self._path, timeout=self._timeout, isolation_level=None
        )
        try:
            connection.execute("PRAGMA synchronous = FULL")
        except BaseException:
            connection.close()
            raise
        return connection

    def _lookup(self, connection: sqlite3.Connection, key: str) -> object:
        """An independent JSON value, or the private absence sentinel."""
        row = connection.execute(
            "SELECT value FROM _unstd_cache_v1 WHERE namespace = ? AND key = ? "
            "AND (expires_at IS NULL OR expires_at > ?)",
            (self._namespace, key, time.time()),
        ).fetchone()
        return _MISSING if row is None else jsonx.loads(row[0])

    def _store(
        self,
        connection: sqlite3.Connection,
        key: str,
        payload: bytes,
        ttl: float | None,
    ) -> None:
        """Publish and enforce namespace retention inside an owned transaction."""
        now = time.time()
        expires_at = None if ttl is None else now + ttl
        if expires_at is not None and not math.isfinite(expires_at):
            msg = "ttl expiry is outside the finite timestamp range"
            raise ValueError(msg)
        # A transactionally assigned sequence preserves FIFO under clock changes.
        connection.execute(
            "INSERT INTO _unstd_cache_v1 "
            "(namespace, key, value, expires_at, written_at) "
            "VALUES (?, ?, ?, ?, (SELECT COALESCE(MAX(written_at), 0) + 1 "
            "FROM _unstd_cache_v1 WHERE namespace = ?)) "
            "ON CONFLICT(namespace, key) DO UPDATE SET "
            "value = excluded.value, expires_at = excluded.expires_at, "
            "written_at = excluded.written_at",
            (self._namespace, key, payload, expires_at, self._namespace),
        )
        # Include the new row: an immediate expiry must not evict live results.
        connection.execute(
            "DELETE FROM _unstd_cache_v1 WHERE namespace = ? AND expires_at <= ?",
            (self._namespace, now),
        )
        if self._max_entries is not None:
            connection.execute(
                "DELETE FROM _unstd_cache_v1 WHERE namespace = ? AND key IN "
                "(SELECT key FROM _unstd_cache_v1 WHERE namespace = ? "
                "ORDER BY written_at DESC LIMIT -1 OFFSET ?)",
                (self._namespace, self._namespace, self._max_entries),
            )

    def get(self, key: str, default: Any = None) -> Any:
        """The decoded live value, or *default* when absent or expired.

        ``None`` is a cacheable value; pass a sentinel as *default* to distinguish
        it from absence. Malformed stored JSON raises instead of becoming a miss.
        Reads do not refresh TTL, eviction order or write to the database.
        """
        _text(key, "key")
        with closing(self._connect()) as connection:
            value = self._lookup(connection, key)
        return default if value is _MISSING else value

    def set(self, key: str, value: Json, *, ttl: float | None = None) -> None:
        """Atomically replace *key* with JSON, expiring after *ttl* seconds.

        ``None`` means no expiry; zero expires immediately. TTL starts after
        encoding and lock acquisition. JSON normalization follows stdlib JSON:
        tuple inputs become lists and supported non-string object keys become
        strings. Nonfinite numbers and unserializable values raise before writing.
        """
        _text(key, "key")
        duration = None if ttl is None else _seconds(ttl, "ttl")
        payload = _encode(value)
        with closing(self._connect()) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            self._store(connection, key, payload, duration)

    def delete(self, key: str) -> bool:
        """Remove *key*, returning whether a stored row existed (even if expired)."""
        _text(key, "key")
        with closing(self._connect()) as connection:
            result = connection.execute(
                "DELETE FROM _unstd_cache_v1 WHERE namespace = ? AND key = ?",
                (self._namespace, key),
            )
            return result.rowcount != 0

    def clear(self) -> int:
        """Remove all stored rows in this namespace, returning their count."""
        with closing(self._connect()) as connection:
            result = connection.execute(
                "DELETE FROM _unstd_cache_v1 WHERE namespace = ?", (self._namespace,)
            )
            return result.rowcount

    def get_or_compute(
        self,
        key: str,
        factory: Callable[[], Json],
        *,
        ttl: float | None = None,
    ) -> Json:
        """The live result, computing and publishing once on a simultaneous miss.

        After a fast read, a miss takes the database's write transaction and
        rechecks before calling *factory*. Other processes wait and reuse the
        published value. Independent WAL readers can still read committed hits.
        ALL writes and cold fills in the database serialize, including across
        namespaces; factories must not write to this database. A lock wait beyond
        ``timeout`` raises ``sqlite3.OperationalError`` without calling *factory*.

        Producer/encoding failures roll back. TTL starts after successful
        computation and encoding. Both cold and warm results are decoded JSON,
        independent of the producer's mutable objects. A crash, expiry, eviction
        or explicit removal can cause later recomputation; external side effects
        are not covered by the database transaction.
        """
        _text(key, "key")
        duration = None if ttl is None else _seconds(ttl, "ttl")
        if not callable(factory):
            msg = "factory must be callable"
            raise TypeError(msg)
        with closing(self._connect()) as connection:
            value = self._lookup(connection, key)
            if value is not _MISSING:
                return cast("Json", value)
            with connection:
                connection.execute("BEGIN IMMEDIATE")
                value = self._lookup(connection, key)
                if value is not _MISSING:
                    return cast("Json", value)
                payload = _encode(factory())
                value = jsonx.loads(payload)
                self._store(connection, key, payload, duration)
            return cast("Json", value)
